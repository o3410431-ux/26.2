package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/** Watches the arrows you shoot. An arrow that hits a map (a map in an item frame) is a WIN for the oldest unfinished arrow game line.
 *  An arrow that hits nothing, or hits anything else (a block, a player, an empty frame), is a LOSS. */
public final class ArrowWatch {
    private static final class Track {
        final List<Vec3> path = new ArrayList<>();
        int still = 0, age = 0;
    }

    private static final Map<Integer, Track> tracks = new HashMap<>();
    private static final Set<Integer> finished = new HashSet<>();   // arrows already counted (still lodged in the world)

    public static void tick(Minecraft mc) {
        ClientLevel world = mc.level;
        if (world == null || mc.player == null || !ArrowGame.enabled || !ArrowGame.autoResults) {
            tracks.clear();
            finished.clear();
            return;
        }

        Set<Integer> present = new HashSet<>();
        for (Entity e : world.entitiesForRendering()) {
            if (!(e instanceof Projectile arrow) || arrow.getOwner() != mc.player) continue;
            EntityType<?> type = e.getType();
            if (type != EntityType.ARROW && type != EntityType.SPECTRAL_ARROW && type != EntityType.TRIDENT) continue;
            int id = e.getId();
            present.add(id);
            if (finished.contains(id)) continue;

            Vec3 pos = e.position();
            Track t = tracks.get(id);
            if (t == null) {
                t = new Track();
                t.path.add(pos);
                tracks.put(id, t);
                continue;
            }
            t.age++;
            Vec3 last = t.path.get(t.path.size() - 1);
            if (pos.distanceToSqr(last) < 1.0E-4) t.still++;
            else { t.still = 0; t.path.add(pos); }

            // lodged in a block, or flying for far too long: it missed the map
            if (t.still >= 3 || t.age > 400) {
                finished.add(id);
                tracks.remove(id);
                Payments.arrowResult(false);
            }
        }
        finished.retainAll(present);

        // an arrow that disappeared hit something that removed it (an item frame, a player ...) or left the world
        Iterator<Map.Entry<Integer, Track>> it = tracks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Track> en = it.next();
            if (present.contains(en.getKey())) continue;
            it.remove();
            Payments.arrowResult(hitMap(world, en.getValue().path, mc));
        }
    }

    /** Follows the arrow's path and says what it reached first. True only if that was an item frame holding a map. */
    private static boolean hitMap(ClientLevel world, List<Vec3> path, Minecraft mc) {
        if (path.size() < 2) return false;
        AABB all = new AABB(path.get(0), path.get(0));
        for (Vec3 p : path) all = all.minmax(new AABB(p, p));
        List<ItemFrame> frames = world.getEntitiesOfClass(ItemFrame.class, all.inflate(2.0), f -> true);
        if (frames.isEmpty()) return false;

        for (int i = 0; i + 1 < path.size(); i++) {
            Vec3 a = path.get(i), b = path.get(i + 1);

            double frameD = Double.MAX_VALUE;
            boolean frameHasMap = false;
            for (ItemFrame f : frames) {
                Optional<Vec3> hit = f.getBoundingBox().inflate(0.05).clip(a, b);
                if (hit.isPresent()) {
                    double d = a.distanceToSqr(hit.get());
                    if (d < frameD) { frameD = d; frameHasMap = f.getItem().is(Items.FILLED_MAP); }
                }
            }

            BlockHitResult bh = world.clip(new ClipContext(a, b, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, mc.player));
            double blockD = bh.getType() == HitResult.Type.BLOCK ? a.distanceToSqr(bh.getLocation()) : Double.MAX_VALUE;

            if (frameD < Double.MAX_VALUE || blockD < Double.MAX_VALUE) return frameD <= blockD && frameHasMap;   // whichever came first
        }
        return false;
    }
}
