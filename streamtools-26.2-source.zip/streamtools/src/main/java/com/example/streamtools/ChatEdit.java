package com.example.streamtools;

import com.example.streamtools.mixin.ChatHudAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.GuiMessage;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.Optional;

public final class ChatEdit {
    private static boolean broken = false;

    /** False only if the chat could not be edited at all (the mixin failed). */
    public static boolean working() { return !broken; }

    private static ChatHudAccessor accessor() {
        ChatComponent hud = Minecraft.getInstance().gui.getChat();
        return (ChatHudAccessor) hud;
    }

    /** Does this chat line carry the hidden marker of payment number id? (Its [X] / [Lose] button runs "st <id>".) */
    private static boolean hasMarker(Component t, String cmd) {
        if (t == null) return false;
        return t.<Boolean>visit((style, s) -> {
            ClickEvent ce = style.getClickEvent();
            if (ce instanceof ClickEvent.RunCommand rc && cmd.equals(rc.command())) return Optional.of(Boolean.TRUE);
            return Optional.empty();
        }, Style.EMPTY).isPresent();
    }

    /** Finds the chat line for payment id: the same text object first, then the line whose button carries the id.
     *  Matching by the id means it works even if another mod re-wraps the message, and never touches a look-alike line. */
    private static int find(List<GuiMessage> list, int id, Component target) {
        if (target != null) for (int i = 0; i < list.size(); i++) if (list.get(i).content() == target) return i;
        String cmd = "st " + id;
        for (int i = 0; i < list.size(); i++) if (hasMarker(list.get(i).content(), cmd)) return i;
        return -1;
    }

    /** Is this payment's line still in the chat history? (Old lines fall out of it.) */
    public static boolean exists(int id, Component shown) {
        try {
            return find(accessor().getMessages(), id, shown) >= 0;
        } catch (Throwable t) {
            broken = true;
            return true;   // can't tell, so assume it is still there
        }
    }

    /** Swaps payment id's line for a new one in the same place. Returns false if the line is no longer in chat. */
    public static boolean replace(int id, Component oldLine, Component newLine) {
        try {
            ChatHudAccessor acc = accessor();
            List<GuiMessage> list = acc.getMessages();
            int i = find(list, id, oldLine);
            if (i < 0) return false;
            GuiMessage l = list.get(i);
            list.set(i, new GuiMessage(l.addedTime(), newLine, l.signature(), l.tag()));
            acc.callRefresh();
            return true;
        } catch (Throwable t) {
            broken = true;
            return false;
        }
    }
}
