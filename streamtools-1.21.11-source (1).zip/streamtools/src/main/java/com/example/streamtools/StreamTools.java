package com.example.streamtools;

import com.mojang.brigadier.arguments.*;
import net.fabricmc.api.ClientModInitializer;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.resources.Identifier;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StreamTools implements ClientModInitializer {
    // !! Adjust these two patterns to match the server's real chat lines !!
    static final Pattern RECEIVED = Pattern.compile("(\\.?\\w{3,16}) paid you \\$?\\s*([\\d.,]+[kKmMbBtT]?)");
    static final Pattern SENT = Pattern.compile("You paid (\\.?\\w{3,16}) \\$?\\s*([\\d.,]+[kKmMbBtT]?)");
    // The reply to /bal: first any "$ amount", then a number after the words balance / money
    static final Pattern MONEY_ANY = Pattern.compile("\\$\\s*([\\d.,]+[kKmMbBtT]?)");
    static final Pattern MONEY_WORD = Pattern.compile("(?i)(?:balance|money|bal)\\D{0,15}(\\d[\\d.,]*[kKmMbBtT]?)");
    static final Pattern BOUGHT = Pattern.compile("You bought .+ for \\$?\\s*([\\d.,]+[kKmMbBtT]?)");
    static final Pattern SOLD = Pattern.compile("You sold .+ for \\$?\\s*([\\d.,]+[kKmMbBtT]?)");

    private static KeyMapping openGui, openAuctionSetup;
    /** When you last ran /bal. The next message within a few seconds is read as your balance. */
    private static long balAskedAt = 0;
    /** The player whose balance you just checked (not you), so their reply is never read as yours. */
    private static String otherName = null;
    private static long otherUntil = 0;

    /** The message as plain text for matching. Servers can put a player-head icon in a chat line (it shows up when that
     *  player is near you); its placeholder text, symbols and odd spacing must not get between the name and "paid you". */
    static String clean(String s) {
        if (s == null) return null;
        s = ChatFormatting.stripFormatting(s);
        if (s == null) return null;
        s = s.replaceAll("(?i)\\[[^\\]]{0,40}(?:head|face|skin|player|icon|sprite|atlas|object)[^\\]]{0,40}\\]", " ");   // [head], [player: Bob] ...
        s = s.replaceAll("[\\p{Co}\\p{Cf}\\p{Cs}\\p{So}\\p{Cn}]", " ");                                                     // icon glyphs, invisible characters
        s = s.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
        return s;
    }

    /** A copy of the line made only of plain styled text: any player-head icon is left out. A line with an icon in it
     *  can make clicks land on the wrong spot, so the payment buttons are put on this icon-free copy instead. */
    static Component flat(Component t) {
        net.minecraft.network.chat.MutableComponent out = Component.empty();
        boolean[] first = {true};
        t.visit((style, str) -> {
            String p = str.replaceAll("(?i)\\[[^\\]]{0,40}(?:head|face|skin|player|icon|sprite|atlas|object)[^\\]]{0,40}\\]", "")
                .replaceAll("[\\p{Co}\\p{Cf}\\p{Cs}\\p{So}\\p{Cn}]", "").replace('\u00A0', ' ');
            if (first[0]) p = p.stripLeading();
            if (!p.isEmpty()) { out.append(Component.literal(p).setStyle(style)); first[0] = false; }
            return java.util.Optional.empty();
        }, Style.EMPTY);
        return out;
    }

    private static boolean namesOtherPlayer(String raw) {
        return otherName != null && System.currentTimeMillis() < otherUntil && raw.toLowerCase().contains(otherName);
    }

    @Override
    public void onInitializeClient() {
        Hud.init();
        Tracker.load();
        ArrowGame.load();
        Settings.load();
        ClientSendMessageEvents.COMMAND.register(cmd -> {
            Payments.commandSent(cmd);
            String c = cmd.trim().toLowerCase();
            String[] parts = c.split("\\s+");
            if (parts.length >= 1 && (parts[0].equals("bal") || parts[0].equals("balance") || parts[0].equals("money"))) {
                String me = Minecraft.getInstance().getUser().getName().toLowerCase();
                if (parts.length == 1 || parts[1].replaceFirst("^\\.", "").equals(me)) {
                    balAskedAt = System.currentTimeMillis();            // your own balance
                } else {
                    balAskedAt = 0;                                     // someone else's: never touches your profit
                    otherName = parts[1].replaceFirst("^\\.", "");
                    otherUntil = System.currentTimeMillis() + 10_000;
                }
            }
        });

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("streamtools", "main"));
        // Right Shift opens the panel, 0 jumps straight to Auction setup. Both can be changed in Controls.
        openGui = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.streamtools.open_panel", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        openAuctionSetup = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.streamtools.open_auction_setup", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_0, category));

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            String raw = clean(message.getString());
            if (raw == null) return;

            // Just ran /bal: read your exact balance from the reply and set up Profit with it
            if (balAskedAt != 0 && System.currentTimeMillis() - balAskedAt < 6000
                && !RECEIVED.matcher(raw).find() && !SENT.matcher(raw).find()
                && !BOUGHT.matcher(raw).find() && !SOLD.matcher(raw).find()
                && !namesOtherPlayer(raw)) {
                Matcher mb = MONEY_ANY.matcher(raw);
                if (!mb.find()) { mb = MONEY_WORD.matcher(raw); if (!mb.find()) mb = null; }
                if (mb != null) {
                    double bal = Money.parse(mb.group(1));
                    if (bal >= 0) {
                        balAskedAt = 0;
                        boolean first = Tracker.balanceFromServer(bal);
                        if (first) say(Component.literal("Profit: starting balance set to " + Money.fmt(bal) + " from /bal").withStyle(ChatFormatting.GRAY));
                        else {
                            double p = Tracker.balanceProfit();
                            say(Component.literal("Profit synced to " + Money.fmt(bal) + ": ").withStyle(ChatFormatting.GRAY)
                                .append(Component.literal((p >= 0 ? "up " : "down ") + Money.fmt(Math.abs(p))).withStyle(p >= 0 ? ChatFormatting.GREEN : ChatFormatting.RED)));
                        }
                        return;
                    }
                }
            }

            Matcher in = RECEIVED.matcher(raw);
            if (in.find()) {
                double amt = Money.parse(in.group(2));
                if (amt > 0) onPaid(in.group(1), amt);
                return;
            }
            Matcher out = SENT.matcher(raw);
            if (out.find()) {
                double amt = Money.parse(out.group(2));
                if (amt > 0) { Tracker.addSent(amt); Payments.sentTo(out.group(1), amt); }
                return;
            }
            Matcher bought = BOUGHT.matcher(raw);
            if (bought.find()) {
                double amt = Money.parse(bought.group(1));
                if (amt > 0) Tracker.spent(amt);
                return;
            }
            Matcher sold = SOLD.matcher(raw);
            if (sold.find()) {
                double amt = Money.parse(sold.group(1));
                if (amt > 0) Tracker.earned(amt);
            }
        });

        ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> {
            if (overlay) return message;
            String raw = clean(message.getString());
            if (raw == null) return message;
            Matcher m = RECEIVED.matcher(raw);
            if (!m.find()) return message;
            double amt = Money.parse(m.group(2));
            if (amt <= 0) return message;
            String name = m.group(1);
            Component flatMsg = flat(message);
            Component base = flatMsg.getString().contains("paid you") ? flatMsg : message;   // safety: no icon -> same text; if anything looks off, keep the original                  // no player-head icon in the line the buttons go on
            ArrowGame.Tier tier = (ArrowGame.enabled && !Auction.active) ? ArrowGame.find(amt) : null;
            if (tier != null) {
                String cmd = ArrowGame.command(tier, name, amt);
                Payments.Entry entry = Payments.register(name, amt, base);
                entry.deliverCmd = cmd.startsWith("/") ? cmd.substring(1) : cmd;
                entry.buttons = Component.literal(" - ").withStyle(ChatFormatting.GRAY)
                    .append(button("[Deliver]", ChatFormatting.GREEN, new ClickEvent.SuggestCommand(cmd)))
                    .append(Component.literal(" "))
                    .append(button("[Lose]", ChatFormatting.RED, new ClickEvent.RunCommand("st " + entry.id)));
                Component shown = Payments.compose(entry);
                entry.shown = shown;
                return shown;
            }
            // No pay options while an auction runs, or for payments under the minimum.
            if (!Settings.buttons || Auction.active || amt < Settings.minPay) return message;
            Payments.Entry entry = Payments.register(name, amt, base);
            entry.buttons = payButtons(entry.id, name, amt);
            Component shown = Payments.compose(entry);
            entry.shown = shown;
            return shown;
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ArrowWatch.tick(mc);
            while (openGui.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new MainScreen());
            }
            while (openAuctionSetup.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new AuctionScreen());
            }
            if (Auction.expired()) {
                Auction.active = false;
                Auction.ended = true;
                Auction.endedAt = System.currentTimeMillis();
                if (!Auction.topBidder.equals("-")) {
                    say(Component.literal("Auction over! ").withStyle(ChatFormatting.GOLD)
                        .append(Component.literal(Auction.topBidder + " won " + Auction.item + " for " + Money.fmt(Auction.topBid) + " ")
                            .withStyle(ChatFormatting.GREEN))
                        .append(suggest("[Deliver ▶ /orders " + Auction.topBidder + "]", "/orders " + Auction.topBidder)));
                    if (!Double.isNaN(Auction.worth)) {
                        double ap = Auction.profit();
                        say(Component.literal("Auction profit: " + Auction.profitText()).withStyle(ap >= 0 ? ChatFormatting.GOLD : ChatFormatting.RED)
                            .append(Component.literal(" (bids " + Money.fmt(Auction.totalBids) + ", worth " + Money.fmt(Auction.worth) + ")").withStyle(ChatFormatting.GRAY)));
                    }
                } else {
                    say(Component.literal("Auction ended with no bids.").withStyle(ChatFormatting.GRAY));
                }
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> registerCommands(dispatcher));
    }

    /** Someone paid the streamer. The [W] [R] [X] buttons are added to the server's own line (see MODIFY_GAME above). */
    private void onPaid(String name, double amt) {
        Tracker.addReceived(name, amt);
        if (!Auction.active) return;
        Auction.totalBids += amt;
        if (Auction.bid(name, amt))
            say(Component.literal("New top bid: " + name + " - " + Money.fmt(amt)).withStyle(ChatFormatting.YELLOW));
        else
            say(Component.literal(name + " paid " + Money.fmt(amt) + " (below the minimum or not enough to lead)")
                .withStyle(ChatFormatting.GRAY));
    }

    /** " - [W] [R] [X]" for a payment from this player. [X] marks the line LOST; paying them 2x / 1x marks it WON / REPAID. */
    static Component payButtons(int id, String name, double amt) {
        return Component.literal(" - ").withStyle(ChatFormatting.GRAY)
            .append(button("[W]", ChatFormatting.GREEN, new ClickEvent.SuggestCommand("/pay " + name + " " + Money.abbr(amt * Settings.winMult))))
            .append(Component.literal(" "))
            .append(button("[R]", ChatFormatting.YELLOW, new ClickEvent.SuggestCommand("/pay " + name + " " + Money.abbr(amt))))
            .append(Component.literal(" "))
            .append(button("[X]", ChatFormatting.RED, new ClickEvent.RunCommand("st " + id)));
    }

    static Component button(String label, ChatFormatting color, ClickEvent click) {
        return Component.literal(label).setStyle(Style.EMPTY.withColor(color).withBold(true).withClickEvent(click));
    }

    // ---- commands -------------------------------------------------------
    private void registerCommands(com.mojang.brigadier.CommandDispatcher<FabricClientCommandSource> d) {
        // /st opens the panel. "/st <number>" is what the [X] and [Lose] buttons run behind the scenes.
        var root = LiteralArgumentBuilder.<FabricClientCommandSource>literal("st")
            .executes(c -> { MainScreen.open(); return 1; })
            .then(RequiredArgumentBuilder.<FabricClientCommandSource, Integer>argument("id", IntegerArgumentType.integer(1))
                .executes(c -> { Payments.lose(IntegerArgumentType.getInteger(c, "id")); return 1; }));

        d.register(LiteralArgumentBuilder.<FabricClientCommandSource>literal("profit").executes(c -> { showProfit(); return 1; }));

        d.register(root);
    }

    /** /profit: today's money in, money out and what is left. */
    static void showProfit() {
        double in = Tracker.todayIn(), out = Tracker.todayOut(), p = in - out;
        ChatFormatting col = p >= 0 ? ChatFormatting.GREEN : ChatFormatting.RED;
        say(Component.literal("Profit: ").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
            .append(Component.literal((p > 0 ? "+" : "") + Money.fmt(p)).withStyle(col)));
        say(Component.literal("Received: ").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
            .append(Component.literal(Money.fmt(in)).withStyle(ChatFormatting.GREEN)));
        say(Component.literal("Sent out: ").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
            .append(Component.literal(Money.fmt(out)).withStyle(ChatFormatting.RED)));
    }

    // ---- helpers --------------------------------------------------------
    /** Clickable text that only PASTES the command into the chat box - it never sends it. */
    static Component suggest(String label, String command) {
        return Component.literal(label).setStyle(Style.EMPTY.withColor(ChatFormatting.AQUA).withUnderlined(true)
            .withClickEvent(new ClickEvent.SuggestCommand(command)));
    }

    static void say(Component t) {
        var p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(t, false);
    }
}
