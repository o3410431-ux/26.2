# 1.21.11 port notes (ported from the 26.2 source, NOT compiled)

This keeps the Mojang names the 26.2 source already used and builds with `mappings loom.officialMojangMappings()`
on Minecraft 1.21.11 (Java 21). Only the 26.x renames were undone:

- GuiGraphicsExtractor -> GuiGraphics; text(...) -> drawString(...); item(...) -> renderItem(...)
- extractRenderState -> render (every Screen); extractContents -> renderContents (StyledButton, AuctionScreen.ItemRow)
- mc.gui.setScreen / mc.gui.screen() -> mc.setScreen / mc.screen
- KeyMappingHelper (client.keymapping.v1) -> KeyBindingHelper.registerKeyBinding (client.keybinding.v1)
- build.gradle: Loom 1.14, Mojang mappings, modImplementation, Java 21; fabric.mod.json: minecraft ~1.21.11, java >=21

If the build fails, the errors will almost certainly be in this short list of guesses:

- StyledButton / AuctionScreen.ItemRow: `renderContents(GuiGraphics, int, int, float)` is the hook that repaints a Button's label.
  If the name is wrong, find the method AbstractButton.renderWidget calls to draw the label.
- StreamTools.java: KeyBindingHelper (may be named KeyMappingHelper in your Fabric API version; use whichever imports),
  KeyMapping.Category.register(Identifier).
- HudPositionScreen.java: Window.handle() (older versions call it getWindow()).
- Hud.java: HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, ...) and Identifier (was ResourceLocation before 1.21.11).
- StreamTools.say(): uses player.displayClientMessage(text, false) (26.x had sendSystemMessage).
- ChatEdit.java finds chat internals by type at run time, so it should need no change.
- gradle.properties: loader/Fabric API versions are placeholders; copy the real ones from https://fabricmc.net/develop.
