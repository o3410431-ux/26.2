package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.RecordComponent;
import java.util.List;
import java.util.Optional;

/**
 * Swaps one chat line for another (turns [W] [R] [X] into the result). The chat's own classes are found at run time
 * (by type, not by name), so a renamed method or a moved class in a new Minecraft version can't stop the mod building.
 */
public final class ChatEdit {
    private static boolean broken = false;
    private static Field listField;
    private static Method refreshMethod;

    /** False only if the chat could not be edited at all. */
    public static boolean working() { return !broken; }

    private static ChatComponent chat() throws Exception {
        Object gui = Minecraft.getInstance().gui;
        for (Method m : gui.getClass().getMethods())
            if (m.getParameterCount() == 0 && ChatComponent.class.isAssignableFrom(m.getReturnType()))
                return (ChatComponent) m.invoke(gui);
        for (Class<?> k = gui.getClass(); k != null; k = k.getSuperclass())
            for (Field f : k.getDeclaredFields())
                if (ChatComponent.class.isAssignableFrom(f.getType())) { f.setAccessible(true); return (ChatComponent) f.get(gui); }
        throw new IllegalStateException("chat not found");
    }

    /** The list of every chat line (its entries are Minecraft's GuiMessage records). */
    @SuppressWarnings("unchecked")
    private static List<Object> messages(ChatComponent chat) throws Exception {
        if (listField == null) {
            for (Field f : ChatComponent.class.getDeclaredFields()) {
                if (!List.class.isAssignableFrom(f.getType())) continue;
                if (f.getGenericType() instanceof ParameterizedType pt && pt.getActualTypeArguments()[0].getTypeName().endsWith("GuiMessage")) {
                    f.setAccessible(true);
                    listField = f;
                    break;
                }
            }
            if (listField == null) throw new IllegalStateException("chat list not found");
        }
        return (List<Object>) listField.get(chat);
    }

    private static void refresh(ChatComponent chat) throws Exception {
        if (refreshMethod == null) {
            for (Method m : ChatComponent.class.getDeclaredMethods()) {
                if (m.getParameterCount() == 0 && m.getReturnType() == void.class && m.getName().toLowerCase().contains("refresh")) {
                    m.setAccessible(true);
                    refreshMethod = m;
                    break;
                }
            }
        }
        if (refreshMethod != null) refreshMethod.invoke(chat);
    }

    private static Object component(Object line, String name) throws Exception {
        for (RecordComponent rc : line.getClass().getRecordComponents())
            if (rc.getName().equals(name)) { Method a = rc.getAccessor(); a.setAccessible(true); return a.invoke(line); }
        return null;
    }

    private static Component content(Object line) {
        try { return (Component) component(line, "content"); } catch (Exception e) { return null; }
    }

    /** The same chat line with its text replaced. */
    private static Object withContent(Object line, Component text) throws Exception {
        RecordComponent[] rcs = line.getClass().getRecordComponents();
        Class<?>[] types = new Class<?>[rcs.length];
        Object[] vals = new Object[rcs.length];
        for (int i = 0; i < rcs.length; i++) {
            types[i] = rcs[i].getType();
            Method a = rcs[i].getAccessor(); a.setAccessible(true);
            vals[i] = rcs[i].getName().equals("content") ? text : a.invoke(line);
        }
        var ctor = line.getClass().getDeclaredConstructor(types);
        ctor.setAccessible(true);
        return ctor.newInstance(vals);
    }

    /** Does this chat line carry the hidden marker of payment number id? (Its [X] / [Lose] button runs "st <id>".) */
    private static boolean hasMarker(Component t, String cmd) {
        if (t == null) return false;
        return t.<Boolean>visit((style, s) -> {
            ClickEvent ce = style.getClickEvent();
            if (ce instanceof ClickEvent.RunCommand rc && cmd.equals(rc.command())) return Optional.of(Boolean.TRUE);
            return Optional.empty();
        }, Style.EMPTY).isPresent();
    }

    /** Finds the chat line for payment id: the same text object first, then the line whose button carries the id. */
    private static int find(List<Object> list, int id, Component target) {
        if (target != null) for (int i = 0; i < list.size(); i++) if (content(list.get(i)) == target) return i;
        String cmd = "st " + id;
        for (int i = 0; i < list.size(); i++) if (hasMarker(content(list.get(i)), cmd)) return i;
        return -1;
    }

    /** Is this payment's line still in the chat history? (Old lines fall out of it.) */
    public static boolean exists(int id, Component shown) {
        try {
            return find(messages(chat()), id, shown) >= 0;
        } catch (Throwable t) {
            broken = true;
            return true;   // can't tell, so assume it is still there
        }
    }

    /** Swaps payment id's line for a new one in the same place. Returns false if the line is no longer in chat. */
    public static boolean replace(int id, Component oldLine, Component newLine) {
        try {
            ChatComponent chat = chat();
            List<Object> list = messages(chat);
            int i = find(list, id, oldLine);
            if (i < 0) return false;
            list.set(i, withContent(list.get(i), newLine));
            refresh(chat);
            return true;
        } catch (Throwable t) {
            broken = true;
            return false;
        }
    }
}
