package com.example.streamtools;

import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import java.util.ArrayList;
import java.util.List;

/** Remembers the payment and arrow game lines that got buttons, so the buttons can turn into the result
 *  and the oldest unfinished line can be marked CURRENT. */
public final class Payments {
    public static final class Entry {
        final int id; final String name; final double amt; final Component base;
        Component buttons = Component.empty();   // what follows base while the line is open: " - [W] [R] [X]" or " [Deliver] [Lose]"
        Component shown; boolean done; boolean current;
        boolean skipped;               // set by "Reset Current": still clickable, but no longer part of the Current queue
        String deliverCmd;             // arrow game: the command (no slash) that marks the line DELIVERED when you send it
        Entry(int id, String name, double amt, Component base) { this.id = id; this.name = name; this.amt = amt; this.base = base; }
    }

    private static final List<Entry> entries = new ArrayList<>();
    private static int nextId = 1;

    public static Entry register(String name, double amt, Component base) {
        Entry e = new Entry(nextId++, name, amt, base);
        e.current = firstOpen() == null;   // nothing else waiting: this one is the one to do next
        entries.add(e);
        if (entries.size() > 500) entries.remove(0);
        return e;
    }

    /** The line as it should look right now: "Current > " in front of the name while it is the next one to do, then base + buttons. */
    public static Component compose(Entry e) {
        MutableComponent t = Component.empty();
        if (e.current) t.append(Component.literal("Current > ").withStyle(ChatFormatting.LIGHT_PURPLE));
        t.append(e.base).append(e.buttons);
        return t;
    }

    /** The oldest unfinished line that is still in the chat. Lines that scrolled out of the chat history are forgotten. */
    private static Entry firstOpen() {
        for (Entry e : entries) {
            if (e.done || e.skipped) continue;
            if (e.shown != null && !ChatEdit.exists(e.id, e.shown)) { e.done = true; continue; }
            return e;
        }
        return null;
    }

    /** Payment buttons > Reset Current: forget the waiting lines. "Current >" comes off, and the next payment that arrives gets it.
     *  Old lines keep working if you click them. Returns how many lines were cleared. */
    public static int resetQueue() {
        int n = 0;
        for (Entry e : entries) {
            if (e.done || e.skipped) continue;
            e.skipped = true;
            n++;
            if (e.current) {
                e.current = false;
                Component updated = compose(e);
                if (ChatEdit.replace(e.id, e.shown, updated)) e.shown = updated;
            }
        }
        return n;
    }

    /** The arrow game saw a shot. A hit on a map is a win, anything else a loss. It goes to the oldest unfinished arrow game line.
     *  Returns false if there is no such line waiting. */
    public static boolean arrowResult(boolean win) {
        for (Entry e : entries) {
            if (e.done || e.skipped || e.deliverCmd == null) continue;
            if (e.shown != null && !ChatEdit.exists(e.id, e.shown)) { e.done = true; continue; }
            if (win) resolveWin(e); else resolve(e, "LOST \u2716", ChatFormatting.RED);
            return true;
        }
        return false;
    }

    /** WON, with a [Pay] button that pastes the winnings for you to send. */
    private static void resolveWin(Entry e) {
        e.done = true;
        e.current = false;
        String pay = Money.abbr(e.amt * Settings.winMult);
        Component result = e.base.copy()
            .append(Component.literal(" - ").withStyle(ChatFormatting.GRAY))
            .append(Component.literal("WON \u2714").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD))
            .append(Component.literal(" "))
            .append(StreamTools.button("[Pay " + pay + "]", ChatFormatting.YELLOW,
                new ClickEvent.SuggestCommand("/pay " + e.name + " " + pay)));
        if (ChatEdit.replace(e.id, e.shown, result)) e.shown = result;
        markNext();
    }

    /** [X] or [Lose] was clicked. */
    public static void lose(int id) {
        for (Entry e : entries) if (e.id == id && !e.done) { resolve(e, "LOST \u2716", ChatFormatting.RED); return; }
    }

    /** The server confirmed that you paid someone: the win amount is a WIN payout, 1x is a repay. */
    public static void sentTo(String name, double sent) {
        for (Entry e : entries) {
            if (e.done || !e.name.equalsIgnoreCase(name)) continue;
            if (Math.abs(sent - e.amt * Settings.winMult) < 1) { resolve(e, "WON \u2714", ChatFormatting.GREEN); return; }
            if (Math.abs(sent - e.amt) < 1) { resolve(e, "REPAID \u2714", ChatFormatting.YELLOW); return; }
        }
    }

    /** You sent a command: if it is the deliver command of an arrow game line, that line becomes DELIVERED. */
    public static void commandSent(String cmd) {
        String c = cmd.trim();

        // "/pay <name> <amount>": the moment you send it, the line flips to WON (the win amount) or REPAID (the same amount)
        String[] parts = c.split("\\s+");
        if (parts.length >= 3 && parts[0].equalsIgnoreCase("pay")) {
            double amt = Money.parse(parts[2]);
            if (amt > 0) sentTo(parts[1], amt);
        }

        for (Entry e : entries) {
            if (!e.done && e.deliverCmd != null && e.deliverCmd.equalsIgnoreCase(c)) {
                resolve(e, "DELIVERED \u2714", ChatFormatting.GREEN);
                return;
            }
        }
    }

    private static void resolve(Entry e, String label, ChatFormatting color) {
        e.done = true;
        e.current = false;
        Component result = e.base.copy()
            .append(Component.literal(" - ").withStyle(ChatFormatting.GRAY))
            .append(Component.literal(label).withStyle(color, ChatFormatting.BOLD));
        if (ChatEdit.replace(e.id, e.shown, result)) e.shown = result;
        else if (!ChatEdit.working()) StreamTools.say(Component.literal(label).withStyle(color, ChatFormatting.BOLD));   // only if chat can't be edited at all
        markNext();
    }

    /** Puts "Current >" on the oldest line that isn't finished yet. */
    private static void markNext() {
        Entry first = firstOpen();
        if (first == null || first.current) return;
        first.current = true;
        Component updated = compose(first);
        if (ChatEdit.replace(first.id, first.shown, updated)) first.shown = updated;
    }
}
