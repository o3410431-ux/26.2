package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

public class ArrowScreen extends Screen {
    private static final int LIST_Y = 100;
    private static String lastName = "", lastPrice = "", lastCmd = ArrowGame.DEFAULT_CMD;

    private int W = 300;
    private EditBox nameField, priceField, cmdField;
    private Component status = Component.empty();
    private int x0, y0, rowH = 20, visibleRows = ArrowGame.MAX, priceX;

    public ArrowScreen() { super(Component.literal("Arrow Game Setup")); }

    @Override
    protected void init() {
        W = Math.min(Math.max(240, Settings.menuW(300, width)), width - 12);
        x0 = (width - W) / 2;

        // Back and the on/off button sit in a row at the top, so they can never fall off the bottom.
        // The price list gets whatever room is left under the boxes.
        int max = ArrowGame.MAX;
        rowH = height >= LIST_Y + max * 20 + 18 ? 20 : 16;
        int need = LIST_Y + max * rowH + 8;
        y0 = height >= need + 12 ? (height - need) / 2 : 4;
        visibleRows = Math.max(1, Math.min(max, (height - 6 - (y0 + LIST_Y)) / rowH));

        double k = W / 300.0;
        int nameW = (int) Math.round(150 * k);
        priceX = (int) Math.round(156 * k);
        int priceW = (int) Math.round(90 * k);
        int addX = (int) Math.round(252 * k);

        nameField = new EditBox(font, x0, y0 + 34, nameW, 20, Component.literal("Name"));
        nameField.setMaxLength(24);
        nameField.setHint(Component.literal("e.g. 1 arrow"));
        nameField.setValue(lastName);
        addRenderableWidget(nameField);

        priceField = new EditBox(font, x0 + priceX, y0 + 34, priceW, 20, Component.literal("Price"));
        priceField.setMaxLength(24);
        priceField.setHint(Component.literal("e.g. 500k"));
        priceField.setValue(lastPrice);
        addRenderableWidget(priceField);

        addRenderableWidget(Button.builder(Component.literal("Add"), b -> add())
            .bounds(x0 + addX, y0 + 34, W - addX, 20).build());

        cmdField = new EditBox(font, x0, y0 + 70, W, 20, Component.literal("Deliver command"));
        cmdField.setMaxLength(100);
        cmdField.setValue(lastCmd);
        addRenderableWidget(cmdField);

        for (int i = 0; i < Math.min(ArrowGame.tiers.size(), visibleRows); i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal("X"), b -> { ArrowGame.remove(idx); rebuildWidgets(); })
                .bounds(x0 + W - 22, y0 + LIST_Y + i * rowH, 22, rowH - 2).build());
        }

        // top row: [Back] ...title... [Arrow game: ON]
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> MainScreen.open())
            .bounds(x0, y0, 56, 18).build());
        addRenderableWidget(Button.builder(toggleText(), b -> {
            ArrowGame.setEnabled(!ArrowGame.enabled);
            b.setMessage(toggleText());
        }).bounds(x0 + W - 72, y0, 72, 18).build());
    }

    private Component toggleText() {
        return Component.literal("Arrow: " + (ArrowGame.enabled ? "ON" : "OFF"));
    }

    private void add() {
        lastCmd = cmdField.getValue().trim();
        String name = nameField.getValue().trim();
        double price = Money.parse(priceField.getValue());
        if (name.isEmpty()) { status = Component.literal("Enter a name").withColor(Ui.RED); return; }
        if (price <= 0) { status = Component.literal("Bad price (try 500k, 1.5m, 1b)").withColor(Ui.RED); return; }
        if (!ArrowGame.add(name, price, lastCmd)) { status = Component.literal("List is full (max " + ArrowGame.MAX + ")").withColor(Ui.RED); return; }
        lastName = ""; lastPrice = "";
        status = Component.literal("Saved " + name + " at " + Money.fmt(price)).withColor(Ui.GREEN);
        rebuildWidgets();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor ctx, int mouseX, int mouseY, float delta) {
        super.extractRenderState(ctx, mouseX, mouseY, delta);
        Ui.centered(ctx, font, title, width / 2, y0 + 4, Ui.a(Ui.GOLD));
        Ui.text(ctx, font, "Name", x0, y0 + 22, 0xFFAAAAAA);
        Ui.text(ctx, font, "Price", x0 + priceX, y0 + 22, 0xFFAAAAAA);
        Ui.text(ctx, font, font.plainSubstrByWidth("Deliver command ({name} = the player who paid)", W), x0, y0 + 58, 0xFFAAAAAA);

        if (ArrowGame.tiers.isEmpty())
            Ui.text(ctx, font, "No prices yet - add one above", x0 + 4, y0 + LIST_Y + 5, 0xFF888888);
        for (int i = 0; i < Math.min(ArrowGame.tiers.size(), visibleRows); i++) {
            ArrowGame.Tier t = ArrowGame.tiers.get(i);
            int y = y0 + LIST_Y + i * rowH;
            int ty = y + (rowH - 2 - 8) / 2;
            ctx.fill(x0, y, x0 + W - 26, y + rowH - 2, 0x55000000);
            Ui.text(ctx, font, t.name(), x0 + 6, ty, 0xFFFFFFFF);
            Ui.text(ctx, font, font.plainSubstrByWidth(t.cmd(), Math.max(40, W / 3)), x0 + 6 + W / 3 - 4, ty, 0xFF888888);
            String p = Money.fmt(t.price());
            Ui.text(ctx, font, p, x0 + W - 32 - font.width(p), ty, Ui.a(Ui.GREEN));
        }
        if (ArrowGame.tiers.size() > visibleRows)
            Ui.text(ctx, font, "+" + (ArrowGame.tiers.size() - visibleRows) + " more (make the window taller)", x0, y0 + LIST_Y - 10, 0xFF888888);

        // status sits under the title
        Ui.centered(ctx, font, status, width / 2, y0 + 13, 0xFFFFFFFF);
    }

    @Override public boolean isPauseScreen() { return false; }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.gui.setScreen(new ArrowScreen()));
    }
}
