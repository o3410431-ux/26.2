package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** The one menu for everything. Right Shift or /st. */
public class MainScreen extends Screen {
    private int panelX1, panelY1, panelX2, panelY2, headerH = 34;
    private int chipsY, footerY;

    public MainScreen() { super(Component.literal("Stream Tools")); }

    @Override
    protected void init() {
        boolean roomy = height >= 280;
        int btnH = roomy ? 22 : 18, gap = roomy ? 4 : 3, pad = 12;
        int w = Math.max(170, Math.min(Settings.menuW(220, width), width - 40));
        int total = headerH + pad + 6 * btnH + 5 * gap + 8 + 14 + 12 + pad;
        int top = Math.max(2, (height - total) / 2);

        panelX1 = (width - (w + 2 * pad)) / 2;
        panelX2 = panelX1 + w + 2 * pad;
        panelY1 = top;
        panelY2 = Math.min(height - 2, top + total);
        int x = panelX1 + pad, y = panelY1 + headerH + pad;
        chipsY = y + 6 * btnH + 5 * gap + 8;
        footerY = chipsY + 18;

        addRenderableOnly((c, mx, my, dl) -> {                    // the panel sits behind the buttons
            Ui.panel(c, panelX1, panelY1, panelX2, panelY2, Ui.BLUE);
            Ui.header(c, panelX1, panelY1, panelX2, panelY1 + headerH);
        });

        addRenderableWidget(new StyledButton(x, y, w, btnH, "Auction setup", Ui.ORANGE, Ui.ELYTRA,
            b -> minecraft.gui.setScreen(new AuctionScreen())));
        addRenderableWidget(new StyledButton(x, y + (btnH + gap), w, btnH, "Arrow game", Ui.CYAN, Ui.ARROW,
            b -> minecraft.gui.setScreen(new ArrowScreen())));
        addRenderableWidget(new StyledButton(x, y + 2 * (btnH + gap), w, btnH, "Payment buttons", Ui.GOLD, Ui.COIN,
            b -> minecraft.gui.setScreen(new PaymentsScreen())));
        addRenderableWidget(new StyledButton(x, y + 3 * (btnH + gap), w, btnH, "Profit", Ui.GREEN, Ui.CHART,
            b -> minecraft.gui.setScreen(new ProfitScreen())));
        addRenderableWidget(new StyledButton(x, y + 4 * (btnH + gap), w, btnH, "Settings", Ui.GREY, Ui.GEAR,
            b -> minecraft.gui.setScreen(new SettingsScreen())));
        addRenderableWidget(new StyledButton(x, y + 5 * (btnH + gap), w, btnH, "Close", Ui.RED, Ui.CLOSE,
            b -> onClose()));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor ctx, int mouseX, int mouseY, float delta) {
        super.extractRenderState(ctx, mouseX, mouseY, delta);
        Font tr = font;

        // title, drawn bigger, in the header
        ctx.pose().pushMatrix();
        ctx.pose().translate(panelX1 + 12, panelY1 + 6);
        ctx.pose().scale(1.5f, 1.5f);
        Ui.text(ctx, tr, "STREAM TOOLS", 0, 0, 0xFFFFFFFF);
        ctx.pose().popMatrix();
        Ui.text(ctx, tr, "Bid Mod by Oll1eonMC", panelX1 + 13, panelY1 + 22, 0xFFCFE6FF);

        // status chips
        int cx = panelX1 + 12;
        cx += Ui.chip(ctx, tr, cx, chipsY, "Arrow " + (ArrowGame.enabled ? "ON" : "OFF"), ArrowGame.enabled ? Ui.GREEN : Ui.RED) + 4;
        Ui.chip(ctx, tr, cx, chipsY, "Pay buttons " + (Settings.buttons ? "ON " + Money.abbr(Settings.minPay) + "+" : "OFF"),
            Settings.buttons ? Ui.GREEN : Ui.RED);

        Ui.text(ctx, tr, "Right Shift: panel    0: auction", panelX1 + 12, footerY, 0xFF6F7C94);
    }

    @Override public boolean isPauseScreen() { return false; }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.gui.setScreen(new MainScreen()));
    }
}
