package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class AuctionScreen extends Screen {
    private record Entry(Item item, String name, String lower) {}

    private static final int MAXROWS = 9, ROW_H = 18;
    private static final List<Entry> ALL = new ArrayList<>();
    private static Item selected = null;
    private static String lastSearch = "", lastMin = "100k", lastWorth = "", lastTime = "30", lastSnipe = "";

    private List<Entry> filtered = new ArrayList<>();
    private int page = 0;
    private int rowCount = MAXROWS;
    private final ItemRow[] rows = new ItemRow[MAXROWS];
    private EditBox search, minField, worthField, timeField, snipeField;
    private Component status = Component.empty();
    private int x0, y0, w, pagerY, statusY, panelTop, panelBottom;
    private static final int HEADER_H = 26;
    private final int[] fx = new int[5], fw = new int[5];   // x and width of the five boxes along the top

    public AuctionScreen() { super(Component.literal("Auction Setup")); }

    private static void buildAll() {
        if (!ALL.isEmpty()) return;
        for (Item i : BuiltInRegistries.ITEM) {
            if (i == Items.AIR) continue;
            String n = new ItemStack(i).getHoverName().getString();
            ALL.add(new Entry(i, n, n.toLowerCase(Locale.ROOT)));
        }
        ALL.sort(Comparator.comparing(Entry::lower));
    }

    @Override
    protected void init() {
        buildAll();

        // Width: 400 times the Menu width setting (Settings), never wider than the window
        w = Math.min(Math.max(300, Settings.menuW(400, width)), width - 12);
        x0 = (width - w) / 2;

        // Height: 262 when the window is tall enough. When it is short, the list gets fewer rows
        // and the buttons sit at the bottom of the window, so Back is always on screen.
        boolean tall = height >= 262 + HEADER_H + 16;
        y0 = tall ? HEADER_H + (height - 262 - HEADER_H) / 2 : HEADER_H + 6;
        int by = tall ? y0 + 232 : height - 26;
        panelTop = Math.max(2, y0 - HEADER_H - 2);
        panelBottom = Math.min(height - 2, by + 28);
        statusY = by - 12;
        pagerY = statusY - 18;
        int listTop = y0 + 36;
        rowCount = Math.max(2, Math.min(MAXROWS, (pagerY - 4 - listTop) / ROW_H));

        addRenderableOnly((c, mx, my, dl) -> drawPanel(c));       // the panel sits behind everything else

        double k = w / 400.0;
        int[] bx = {0, 106, 176, 254, 338}, bw = {100, 64, 72, 78, 62};
        for (int i = 0; i < 5; i++) {
            fx[i] = x0 + (int) Math.round(bx[i] * k);
            fw[i] = Math.max(24, (int) Math.round(bw[i] * k));
        }

        search = new EditBox(font, fx[0], y0 + 11, fw[0], 20, Component.literal("Search"));
        search.setMaxLength(64);
        search.setHint(Component.literal("Search items..."));
        search.setValue(lastSearch);
        search.setResponder(s -> { lastSearch = s; applyFilter(s); });
        addRenderableWidget(search);

        minField = new EditBox(font, fx[1], y0 + 11, fw[1], 20, Component.literal("Minimum bid"));
        minField.setMaxLength(24);
        minField.setValue(lastMin);
        addRenderableWidget(minField);

        worthField = new EditBox(font, fx[2], y0 + 11, fw[2], 20, Component.literal("Worth"));
        worthField.setMaxLength(24);
        worthField.setHint(Component.literal("optional"));
        worthField.setValue(lastWorth);
        addRenderableWidget(worthField);

        timeField = new EditBox(font, fx[3], y0 + 11, fw[3], 20, Component.literal("Duration"));
        timeField.setMaxLength(5);
        timeField.setValue(lastTime);
        addRenderableWidget(timeField);

        snipeField = new EditBox(font, fx[4], y0 + 11, fw[4], 20, Component.literal("Anti-snipe"));
        snipeField.setMaxLength(3);
        snipeField.setHint(Component.literal("optional"));
        snipeField.setValue(lastSnipe);
        addRenderableWidget(snipeField);

        for (int i = 0; i < MAXROWS; i++) {
            if (i < rowCount) {
                rows[i] = new ItemRow(x0, listTop + i * ROW_H, w, ROW_H - 1, i);
                addRenderableWidget(rows[i]);
            } else {
                rows[i] = null;
            }
        }

        addRenderableWidget(new StyledButton(x0 + w - 48, pagerY, 22, 16, "<", Ui.BLUE, null, b -> changePage(-1)));
        addRenderableWidget(new StyledButton(x0 + w - 22, pagerY, 22, 16, ">", Ui.BLUE, null, b -> changePage(1)));

        int bw3 = (w - 4) / 3;
        addRenderableWidget(new StyledButton(x0, by, bw3, 20, "Start bid", Ui.GREEN, Ui.ELYTRA, b -> start()));
        addRenderableWidget(new StyledButton(x0 + bw3 + 2, by, bw3, 20, "Stop", Ui.RED, null, b -> {
            Auction.stopNow();
            status = Component.literal("Stopping auction...").withColor(0xFFAA00);
        }));
        addRenderableWidget(new StyledButton(x0 + 2 * bw3 + 4, by, bw3, 20, "Back", Ui.GREY, null, b -> MainScreen.open()));

        setInitialFocus(search);
        applyFilter(lastSearch);
    }

    private void applyFilter(String q) {
        String[] tokens = q.toLowerCase(Locale.ROOT).trim().split("\\s+");
        filtered = new ArrayList<>();
        outer:
        for (Entry e : ALL) {
            for (String t : tokens) if (!t.isEmpty() && !e.lower().contains(t)) continue outer;
            filtered.add(e);
        }
        page = 0;
        refresh();
    }

    private void changePage(int d) {
        int max = Math.max(0, (filtered.size() - 1) / rowCount);
        page = Math.max(0, Math.min(max, page + d));
        refresh();
    }

    private void refresh() {
        for (int i = 0; i < rowCount; i++) {
            int idx = page * rowCount + i;
            if (rows[i] == null) continue;
            rows[i].entry = idx < filtered.size() ? filtered.get(idx) : null;
            rows[i].visible = rows[i].entry != null;
        }
    }

    private void start() {
        lastMin = minField.getValue().trim();
        lastTime = timeField.getValue().trim();
        lastWorth = worthField.getValue().trim();
        if (selected == null) { status = Component.literal("Pick an item from the list").withColor(Ui.RED); return; }
        double min = Money.parse(lastMin);
        if (min < 0) { status = Component.literal("Bad minimum bid (try 500k, 1.5m, 1b)").withColor(Ui.RED); return; }
        double worth = Double.NaN;
        if (!lastWorth.isEmpty()) {
            worth = Money.parse(lastWorth);
            if (worth < 0) { status = Component.literal("Bad worth (try 340m, 1.5b, or leave it empty)").withColor(Ui.RED); return; }
        }
        int secs;
        try { secs = Integer.parseInt(lastTime); }
        catch (NumberFormatException e) { status = Component.literal("Duration must be a whole number").withColor(Ui.RED); return; }
        if (secs < 5 || secs > 3600) { status = Component.literal("Duration must be 5-3600 seconds").withColor(Ui.RED); return; }

        // Snipe is optional: empty means no extra time
        lastSnipe = snipeField.getValue().trim();
        int snipe = 0;
        if (!lastSnipe.isEmpty()) {
            try { snipe = Integer.parseInt(lastSnipe); }
            catch (NumberFormatException e) { status = Component.literal("Snipe must be a whole number of seconds, or empty").withColor(Ui.RED); return; }
            if (snipe < 0 || snipe > 600) { status = Component.literal("Snipe must be 0-600 seconds").withColor(Ui.RED); return; }
        }
        Auction.antiSnipeMs = snipe * 1000L;

        String name = new ItemStack(selected).getHoverName().getString();
        Auction.start(new ItemStack(selected), name, min, secs, worth);
        StreamTools.say(Component.literal("Auction started: " + name + " (min " + Money.fmt(min) + ")").withColor(0xFFAA00));
        onClose();
    }

    /** The dark panel behind the whole screen, with a header band showing the title and the item you picked. */
    private void drawPanel(GuiGraphicsExtractor c) {
        int px1 = Math.max(0, x0 - 10), px2 = Math.min(width, x0 + w + 10);
        Ui.panel(c, px1, panelTop, px2, panelBottom, Ui.ORANGE);
        Ui.header(c, px1, panelTop, px2, panelTop + 22);
        Ui.sprite(c, px1 + 8, panelTop + 7, Ui.ELYTRA, 1);
        Ui.text(c, font, "NEW AUCTION", px1 + 20, panelTop + 7, 0xFFFFFFFF);
        if (selected != null) {
            String name = new ItemStack(selected).getHoverName().getString();
            int tw = font.width(name);
            c.item(new ItemStack(selected), px2 - tw - 32, panelTop + 3);
            Ui.text(c, font, name, px2 - tw - 12, panelTop + 7, 0xFFFFE9A8);
        } else {
            String hint = "Pick an item below";
            Ui.text(c, font, hint, px2 - font.width(hint) - 10, panelTop + 7, 0xFFCFE6FF);
        }
    }

    private void label(GuiGraphicsExtractor ctx, String text, int i) {
        Ui.text(ctx, font, font.plainSubstrByWidth(text, fw[i] + 4), fx[i], y0, 0xFF8FA8C8);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor ctx, int mouseX, int mouseY, float delta) {
        super.extractRenderState(ctx, mouseX, mouseY, delta);
        label(ctx, "Search item", 0);
        label(ctx, "Min bid", 1);
        label(ctx, "Worth", 2);
        label(ctx, "Duration (s)", 3);
        label(ctx, "Snipe (s)", 4);

        int total = filtered.size();
        int from = total == 0 ? 0 : page * rowCount + 1;
        int to = Math.min(total, (page + 1) * rowCount);
        Ui.text(ctx, font, total == 0 ? "No items found" : from + "-" + to + " of " + total,
            x0, pagerY + 4, 0xFFAAAAAA);

        if (!status.getString().isEmpty())
            Ui.text(ctx, font, status, x0, statusY, 0xFFFFFFFF);
        else if (selected != null)
            Ui.text(ctx, font, Component.literal("Selected: " + new ItemStack(selected).getHoverName().getString()), x0, statusY, Ui.a(Ui.GREEN));
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        changePage(v > 0 ? -1 : 1);
        return true;
    }

    @Override public boolean isPauseScreen() { return false; }

    private static void onSelect(Item item) {
        selected = item;
    }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.gui.setScreen(new AuctionScreen()));
    }

    /** One clickable row in the item list: icon + name. */
    private class ItemRow extends Button {
        Entry entry;

        final int slot;

        ItemRow(int x, int y, int w, int h, int slot) {
            // OnPress is Button's own press-callback type
            super(x, y, w, h, Component.empty(), b -> {
                Entry e = ((ItemRow) b).entry;
                if (e != null) onSelect(e.item());
            }, DEFAULT_NARRATION);
            this.slot = slot;
        }

        // renderWidget is final in this version, so draw over the default button inside extractContents
        @Override
        protected void extractContents(GuiGraphicsExtractor c, int mx, int my, float d) {
            if (entry == null) return;
            int x = getX(), y = getY(), x2 = x + getWidth(), y2 = y + getHeight();
            boolean picked = entry.item() == selected;
            int bg = picked ? 0xFF1F5A3A : (isHovered() ? 0xFF283652 : (slot % 2 == 0 ? 0xFF161C28 : 0xFF121722));
            c.fill(x, y, x2, y2, bg);
            if (picked) c.fill(x, y, x + 3, y2, Ui.a(Ui.GREEN));
            else if (isHovered()) c.fill(x, y, x + 3, y2, Ui.a(Ui.BLUE));
            c.item(new ItemStack(entry.item()), x + 6, y + 1);
            Ui.text(c, AuctionScreen.this.font, entry.name(), x + 30, y + 5, picked ? 0xFFEFFFF5 : 0xFFE6EDF8);
        }
    }
}
