package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

/** Setup for the [W] [R] [X] buttons on normal payments. */
public class PaymentsScreen extends Screen {
    private int W = 240;
    private EditBox minField, multField;
    private Component status = Component.empty();
    private int x0, y0;

    public PaymentsScreen() { super(Component.literal("Payment Buttons")); }

    @Override
    protected void init() {
        W = Math.max(200, Settings.menuW(240, width));
        x0 = (width - W) / 2;
        y0 = Math.max(2, Math.min(Math.max(6, (height - 216) / 2), height - 192));

        minField = new EditBox(font, x0, y0 + 44, W, 20, Component.literal("Minimum"));
        minField.setMaxLength(24);
        minField.setValue(Money.abbr(Settings.minPay));
        addRenderableWidget(minField);

        multField = new EditBox(font, x0, y0 + 84, W, 20, Component.literal("Multiplier"));
        multField.setMaxLength(8);
        multField.setValue(Settings.num(Settings.winMult));
        addRenderableWidget(multField);

        addRenderableWidget(Button.builder(toggleText(), b -> {
            Settings.buttons = !Settings.buttons;
            Settings.save();
            b.setMessage(toggleText());
        }).bounds(x0, y0 + 112, W, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Reset Current"), b -> {
            int n = Payments.resetQueue();
            status = Component.literal(n == 0 ? "Nothing was waiting. The next payment gets Current >"
                : "Cleared " + n + " waiting. The next payment gets Current >").withColor(Ui.GREEN);
        }).bounds(x0, y0 + 138, W, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Save"), b -> save())
            .bounds(x0, y0 + 164, W / 2 - 2, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> MainScreen.open())
            .bounds(x0 + W / 2 + 2, y0 + 164, W / 2 - 2, 20).build());
    }

    private Component toggleText() { return Component.literal("Pay buttons: " + (Settings.buttons ? "ON" : "OFF")); }

    private void save() {
        double min = Money.parse(minField.getValue());
        if (min < 0) { status = Component.literal("Bad minimum (try 1m, 500k, 1b)").withColor(Ui.RED); return; }
        double mult;
        try { mult = Double.parseDouble(multField.getValue().trim().toLowerCase().replace("x", "")); }
        catch (NumberFormatException e) { status = Component.literal("Multiplier must be a number").withColor(Ui.RED); return; }
        if (mult < 1 || mult > 100) { status = Component.literal("Multiplier must be 1-100").withColor(Ui.RED); return; }
        Settings.minPay = min;
        Settings.winMult = mult;
        Settings.save();
        status = Component.literal("Saved").withColor(Ui.GREEN);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor ctx, int mouseX, int mouseY, float delta) {
        super.extractRenderState(ctx, mouseX, mouseY, delta);
        Ui.centered(ctx, font, title, width / 2, y0 + 4, Ui.a(Ui.GOLD));
        Ui.text(ctx, font, "Smallest payment that gets [W] [R] [X]", x0, y0 + 32, 0xFFAAAAAA);
        Ui.text(ctx, font, "[W] pays them this many times their payment", x0, y0 + 72, 0xFFAAAAAA);
        Ui.centered(ctx, font, status, width / 2, y0 + 192, 0xFFFFFFFF);
    }

    @Override public boolean isPauseScreen() { return false; }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.gui.setScreen(new PaymentsScreen()));
    }
}
