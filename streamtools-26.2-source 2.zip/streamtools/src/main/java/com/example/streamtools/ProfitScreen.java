package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

/** Type your exact starting balance; /profit then tells you how far up or down you are. */
public class ProfitScreen extends Screen {
    private int W = 270;
    private EditBox startField, curField;
    private Component status = Component.empty();
    private int x0, y0;

    public ProfitScreen() { super(Component.literal("Profit")); }

    @Override
    protected void init() {
        W = Math.max(220, Settings.menuW(270, width));
        x0 = (width - W) / 2;
        y0 = Math.max(2, Math.min(Math.max(6, (height - 210) / 2), height - 184));

        startField = new EditBox(font, x0, y0 + 32, W - 60, 20, Component.literal("Starting balance"));
        startField.setMaxLength(24);
        startField.setHint(Component.literal("e.g. 2.5b or 2503849201"));
        if (Tracker.hasStart()) startField.setValue(Money.plain(Tracker.startBalance()));
        addRenderableWidget(startField);
        addRenderableWidget(Button.builder(Component.literal("Set"), b -> setStart())
            .bounds(x0 + W - 56, y0 + 32, 56, 20).build());

        curField = new EditBox(font, x0, y0 + 74, W - 60, 20, Component.literal("Current balance"));
        curField.setMaxLength(24);
        curField.setHint(Component.literal("e.g. 2.64b"));
        addRenderableWidget(curField);
        addRenderableWidget(Button.builder(Component.literal("Sync"), b -> sync())
            .bounds(x0 + W - 56, y0 + 74, 56, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Reset profit"), b -> resetProfit())
            .bounds(x0, y0 + 128, W, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Stop tracking"), b -> {
            Tracker.clearStart();
            startField.setValue("");
            status = Component.literal("Stopped. Profit today uses payments only").withColor(0xAAAAAA);
        }).bounds(x0, y0 + 152, W / 2 - 2, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> MainScreen.open())
            .bounds(x0 + W / 2 + 2, y0 + 152, W / 2 - 2, 20).build());
    }

    /** Starts the profit again from where you are now: up/down goes back to zero, and so do today's profit, the Live pill and /profit. */
    private void resetProfit() {
        Tracker.resetToday();
        if (Tracker.hasStart()) {
            startField.setValue(Money.plain(Tracker.startBalance()));
            status = Component.literal("Profit reset. Counting from " + Money.fmt(Tracker.startBalance())).withColor(Ui.GREEN);
        } else {
            status = Component.literal("Profit reset to $0").withColor(Ui.GREEN);
        }
    }

    private void setStart() {
        double v = Money.parse(startField.getValue());
        if (v < 0) { status = Component.literal("Bad amount (try 2.5b, 800m, or all the digits)").withColor(Ui.RED); return; }
        Tracker.setStart(v);
        status = Component.literal("Starting balance set to " + Money.fmt(v)).withColor(Ui.GREEN);
    }

    private void sync() {
        double v = Money.parse(curField.getValue());
        if (v < 0) { status = Component.literal("Bad amount (try 2.64b)").withColor(Ui.RED); return; }
        if (!Tracker.syncCurrent(v)) { status = Component.literal("Set your starting balance first").withColor(Ui.RED); return; }
        curField.setValue("");
        status = Component.literal("Current balance set to " + Money.fmt(v)).withColor(Ui.GREEN);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor ctx, int mouseX, int mouseY, float delta) {
        super.extractRenderState(ctx, mouseX, mouseY, delta);
        Ui.centered(ctx, font, title, width / 2, y0 + 4, Ui.a(Ui.GOLD));
        Ui.text(ctx, font, "Starting balance (exact)", x0, y0 + 20, 0xFFAAAAAA);
        Ui.text(ctx, font, "Current balance (type it to fix any drift)", x0, y0 + 62, 0xFFAAAAAA);
        if (Tracker.hasStart()) {
            double p = Tracker.balanceProfit();
            Ui.text(ctx, font, "Now: " + Money.fmt(Tracker.current()) + "   Start: " + Money.fmt(Tracker.startBalance()),
                x0, y0 + 102, Ui.a(Ui.INFO));
            Ui.text(ctx, font, (p >= 0 ? "Up " : "Down ") + Money.fmt(Math.abs(p)),
                x0, y0 + 114, p >= 0 ? Ui.a(Ui.GREEN) : Ui.a(Ui.RED));
        } else {
            Ui.text(ctx, font, "No starting balance set yet", x0, y0 + 102, 0xFF888888);
        }
        Ui.centered(ctx, font, status, width / 2, y0 + 180, 0xFFFFFFFF);
    }

    @Override public boolean isPauseScreen() { return false; }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.gui.setScreen(new ProfitScreen()));
    }
}
