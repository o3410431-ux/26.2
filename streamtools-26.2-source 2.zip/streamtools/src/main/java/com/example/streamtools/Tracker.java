package com.example.streamtools;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Tracker {
    // Session totals (cleared by Settings > Reset session)
    public static double received = 0, sent = 0, bought = 0, sold = 0;
    public static final Map<String, Double> tippers = new HashMap<>();

    // Today's totals: survive restarts, reset at local midnight (or Settings > Reset today).
    // Profit today = payments received + things you sold - payments you sent - things you bought.
    private static LocalDate day = LocalDate.now();
    private static double todayReceived = 0, todaySent = 0, todayBought = 0, todaySold = 0;

    // Exact balance tracking for the Profit screen: you type your starting balance, and every
    // payment / purchase / sale moves "delta"; up or down = delta.
    private static double startBal = Double.NaN, delta = 0;

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("streamtools-today.txt");

    /** Someone paid you. */
    public static void addReceived(String name, double amt) {
        received += amt;
        tippers.merge(name, amt, Double::sum);
        rollover();
        todayReceived += amt;
        delta += amt;
        save();
    }

    /** You paid someone. */
    public static void addSent(double amt) {
        sent += amt;
        rollover();
        todaySent += amt;
        delta -= amt;
        save();
    }

    /** You bought something ("You bought 64 End Crystals for $1.1M"). */
    public static void spent(double amt) {
        bought += amt;
        rollover();
        todayBought += amt;
        delta -= amt;
        save();
    }

    /** You sold something. */
    public static void earned(double amt) {
        sold += amt;
        rollover();
        todaySold += amt;
        delta += amt;
        save();
    }

    public static double profit() { return received + sold - sent - bought; }

    public static double todayProfit() {
        rollover();
        return todayReceived + todaySold - todaySent - todayBought;
    }

    /** Today's money in: payments received + things sold. */
    public static double todayIn() { rollover(); return todayReceived + todaySold; }

    /** Today's money out: payments sent + things bought. */
    public static double todayOut() { rollover(); return todaySent + todayBought; }

    // ---- Profit screen: exact starting balance ----
    public static boolean hasStart() { return !Double.isNaN(startBal); }
    public static double startBalance() { return startBal; }
    public static double current() { return startBal + delta; }
    public static double balanceProfit() { return delta; }

    public static void setStart(double v) { startBal = v; delta = 0; save(); }

    /** You typed your real current balance: fixes any drift (purchases the mod couldn't see). */
    public static boolean syncCurrent(double v) {
        if (!hasStart()) return false;
        delta = v - startBal;
        save();
        return true;
    }

    /** An exact balance from /bal. Sets your starting balance if you haven't set one yet, otherwise updates the current balance. Returns true if it was the start. */
    public static boolean balanceFromServer(double v) {
        if (!hasStart()) { setStart(v); return true; }
        syncCurrent(v);
        return false;
    }

    public static void clearStart() { startBal = Double.NaN; delta = 0; save(); }

    public static String topTipper() {
        return tippers.entrySet().stream().max(Map.Entry.comparingByValue())
            .map(e -> e.getKey() + " (" + Money.fmt(e.getValue()) + ")").orElse("-");
    }

    public static void reset() { received = 0; sent = 0; bought = 0; sold = 0; tippers.clear(); }

    public static void resetToday() {
        day = LocalDate.now();
        todayReceived = 0; todaySent = 0; todayBought = 0; todaySold = 0;
        if (hasStart()) { startBal = current(); delta = 0; }
        save();
    }

    private static void rollover() {
        LocalDate now = LocalDate.now();
        if (!now.equals(day)) {
            day = now;
            todayReceived = 0; todaySent = 0; todayBought = 0; todaySold = 0;
            if (hasStart()) { startBal = current(); delta = 0; }   // a new day starts from where you ended
            save();
        }
    }

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            List<String> l = Files.readAllLines(FILE);
            if (l.size() < 3) return;
            LocalDate saved = LocalDate.parse(l.get(0).trim());
            double sb = Double.NaN, d = 0, tb = 0, ts = 0;
            if (l.size() > 3 && !l.get(3).trim().equals("none")) sb = Double.parseDouble(l.get(3).trim());
            if (l.size() > 4) d = Double.parseDouble(l.get(4).trim());
            if (l.size() > 5) tb = Double.parseDouble(l.get(5).trim());
            if (l.size() > 6) ts = Double.parseDouble(l.get(6).trim());
            startBal = sb; delta = d;
            if (saved.equals(LocalDate.now())) {
                day = saved;
                todayReceived = Double.parseDouble(l.get(1).trim());
                todaySent = Double.parseDouble(l.get(2).trim());
                todayBought = tb; todaySold = ts;
            } else if (hasStart()) {
                startBal = current(); delta = 0;   // new day since last time
            }
        } catch (Exception ignored) { }
    }

    private static void save() {
        try {
            Files.writeString(FILE, day + "\n" + todayReceived + "\n" + todaySent + "\n"
                + (hasStart() ? String.valueOf(startBal) : "none") + "\n" + delta + "\n"
                + todayBought + "\n" + todaySold + "\n");
        } catch (IOException ignored) { }
    }
}
