package com.example.streamtools;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.resources.Identifier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Two things can be on screen: the auction box, and the small "Live | +$348.7M" pill (Settings > Live profit). */
public final class Hud {
    public static boolean visible = true;

    // Auction box
    /** Top-left corner of the auction box. Change it in Settings > Move HUD. */
    public static int x = 6, y = 6;
    public static final int W = 192, H = 104;

    // Live pill. -1 = automatic (top centre)
    public static boolean liveVisible = true;
    public static int liveX = -1, liveY = -1;
    public static final int LIVE_H = 20;

    /** 1.0 = normal. Settings > Move HUD (Smaller / Bigger). Applies to both. */
    public static double scale = 1.0;

    public static int w() { return (int) Math.ceil(W * scale); }
    public static int h() { return (int) Math.ceil(H * scale); }

    // ---- live pill sizing / position ----
    public static String liveText() {
        double v = Auction.active ? Auction.liveFrozen : Tracker.todayProfit();
        return Money.live(v);
    }

    public static int liveW(Font tr) {
        return 8 + tr.width("Live") + 6 + 1 + 7 + tr.width(liveText()) + 8;
    }

    public static int liveScaledW(Font tr) { return (int) Math.ceil(liveW(tr) * scale); }
    public static int liveScaledH() { return (int) Math.ceil(LIVE_H * scale); }

    public static int resolveLiveX(int screenW, int scaledW) {
        int v = liveX >= 0 ? liveX : (screenW - scaledW) / 2;
        return Math.max(0, Math.min(v, screenW - scaledW));
    }

    public static int resolveLiveY(int screenH, int scaledH) {
        int v = liveY >= 0 ? liveY : 6;
        return Math.max(0, Math.min(v, screenH - scaledH));
    }

    public static void init() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.fromNamespaceAndPath("streamtools", "hud"), (ctx, tick) -> {
            if (!visible) return;
            Minecraft mc = Minecraft.getInstance();
            int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
            var m = ctx.pose();

            if (Auction.active || Auction.showEnd()) {
                int ox = Math.max(0, Math.min(x, sw - w()));
                int oy = Math.max(0, Math.min(y, sh - h()));
                m.pushMatrix();
                m.translate(ox, oy);
                m.scale((float) scale, (float) scale);
                drawAuction(ctx, mc.font, 0, 0);
                m.popMatrix();
            }

            if (liveVisible) {
                int lx = resolveLiveX(sw, liveScaledW(mc.font));
                int ly = resolveLiveY(sh, liveScaledH());
                m.pushMatrix();
                m.translate(lx, ly);
                m.scale((float) scale, (float) scale);
                drawLive(ctx, mc.font, 0, 0);
                m.popMatrix();
            }
        });
    }

    /** A rectangle with its four corners cut off. */
    private static void chamfer(GuiGraphicsExtractor c, int x1, int y1, int x2, int y2, int col, int cut) {
        c.fill(x1, y1 + cut, x2, y2 - cut, col);
        for (int i = 0; i < cut; i++) {
            int inset = cut - i;
            c.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, col);
            c.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, col);
        }
    }

    public static void drawLive(GuiGraphicsExtractor c, Font tr, int ox, int oy) {
        double v = Auction.active ? Auction.liveFrozen : Tracker.todayProfit();
        int w = liveW(tr), h = LIVE_H, blue = Ui.a(Ui.BLUE);
        chamfer(c, ox, oy, ox + w, oy + h, blue, 4);
        chamfer(c, ox + 1, oy + 1, ox + w - 1, oy + h - 1, Ui.mix(Ui.a(Ui.BG), 0xFF000000, 0.7f), 3);
        int tx = ox + 8, ty = oy + 6;
        Ui.text(c, tr, "Live", tx, ty, Ui.lighten(Ui.a(Ui.BLUE), 0.25f));
        int barX = tx + tr.width("Live") + 6;
        c.fill(barX, oy + 5, barX + 1, oy + h - 5, blue);
        Ui.text(c, tr, liveText(), barX + 7, ty, v >= 0 ? Ui.a(Ui.GREEN) : Ui.a(Ui.RED));
    }

    private static void border(GuiGraphicsExtractor c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2, y1 + 1, col);
        c.fill(x1, y2 - 1, x2, y2, col);
        c.fill(x1, y1, x1 + 1, y2, col);
        c.fill(x2 - 1, y1, x2, y2, col);
    }

    private static void drawAuction(GuiGraphicsExtractor c, Font tr, int ox, int y) {
        boolean over = !Auction.active;
        boolean sold = !Auction.topBidder.equals("-");
        boolean hasWorth = !Double.isNaN(Auction.worth);
        boolean showProfit = over && sold && hasWorth;   // profit appears at the end, when you typed a worth
        int h = over ? (showProfit ? 102 : (hasWorth ? 78 : 64)) : (hasWorth ? 78 : 66);
        int x1 = ox, x2 = ox + 190, y2 = y + h, blue = Ui.lighten(Ui.a(Ui.BLUE), 0.25f);
        c.fill(x1, y, x2, y2, (0xCC000000 | (Ui.mix(Ui.a(Ui.BG), 0xFF000000, 0.7f) & 0xFFFFFF)));
        border(c, x1, y, x2, y2, blue);
        Ui.text(c, tr, Auction.TITLE, x1 + 8, y + 6, blue);
        if (!Auction.stack.isEmpty()) c.item(Auction.stack, x1 + 8, y + 18);
        Ui.text(c, tr, Auction.item, x1 + 30, y + 22, 0xFFFFFFFF);

        if (over) {
            String line = sold ? "Winner: " + Auction.topBidder + " - " + Money.fmt(Auction.topBid) : "Ended: no bids";
            Ui.text(c, tr, line, x1 + 8, y + 38, sold ? Ui.a(Ui.GREEN) : 0xFFAAAAAA);
            Ui.text(c, tr, "Time: Ended", x1 + 8, y + 51, 0xFFFF7777);
            if (showProfit) {
                double ap = Auction.profit();
                Ui.text(c, tr, "Bids total: " + Money.fmt(Auction.totalBids), x1 + 8, y + 64, Ui.a(Ui.GREEN));
                Ui.text(c, tr, "Worth: " + Money.fmt(Auction.worth), x1 + 8, y + 76, Ui.a(Ui.INFO));
                Ui.text(c, tr, "Auction profit: " + Auction.profitText(), x1 + 8, y + 88,
                    ap >= 0 ? Ui.a(Ui.GOLD) : Ui.a(Ui.RED));
            } else if (hasWorth) {
                Ui.text(c, tr, "Worth: " + Money.fmt(Auction.worth), x1 + 8, y + 64, Ui.a(Ui.INFO));
            }
            return;
        }

        String top = sold ? Money.fmt(Auction.topBid) + " - " + Auction.topBidder : "Waiting for a bid -";
        Ui.text(c, tr, "Top bid: " + top, x1 + 8, y + 38, Ui.a(Ui.GOLD));
        long s = Auction.msLeft() / 1000;
        String time = String.format("Time: %02d:%02d", s / 60, s % 60) + (Auction.overtime ? " (extra)" : "");
        Ui.text(c, tr, time, x1 + 8, y + 51, Auction.overtime ? 0xFFFFAA55 : 0xFFFFFFFF);
        String min = "Min: " + Money.fmt(Auction.minBid);
        Ui.text(c, tr, min, x2 - 8 - tr.width(min), y + 51, 0xFFAAAAAA);
        if (hasWorth) Ui.text(c, tr, "Worth: " + Money.fmt(Auction.worth), x1 + 8, y + 64, Ui.a(Ui.INFO));
    }
}
