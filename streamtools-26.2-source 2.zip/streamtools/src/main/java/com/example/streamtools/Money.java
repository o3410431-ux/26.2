package com.example.streamtools;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class Money {
    private Money() {}

    /** Parses "1.5k", "2m", "1b", "1t", "1,000,000", "$ 2.5M" -> double. Returns -1 on failure. */
    public static double parse(String s) {
        if (s == null) return -1;
        s = s.trim().toLowerCase().replace(",", "").replace("$", "").replace(" ", "");
        if (s.isEmpty()) return -1;
        double mult = 1;
        char c = s.charAt(s.length() - 1);
        if (c == 'k') mult = 1e3; else if (c == 'm') mult = 1e6; else if (c == 'b') mult = 1e9; else if (c == 't') mult = 1e12;
        if (mult != 1) s = s.substring(0, s.length() - 1);
        try { return Double.parseDouble(s) * mult; } catch (NumberFormatException e) { return -1; }
    }

    /** For display on the HUD and in chat: $1.50M */
    public static String fmt(double v) {
        if (v < 0) return "-" + fmt(-v);
        if (v >= 1e9) return String.format("$%.2fB", v / 1e9);
        if (v >= 1e6) return String.format("$%.2fM", v / 1e6);
        if (v >= 1e3) return String.format("$%.1fK", v / 1e3);
        return String.format("$%.0f", v);
    }

    /** Compact signed form for the live pill: +$348.7M */
    public static String live(double v) {
        String sign = v < 0 ? "-" : "+";
        double a = Math.abs(v);
        if (a >= 1e9) return String.format("%s$%.1fB", sign, a / 1e9);
        if (a >= 1e6) return String.format("%s$%.1fM", sign, a / 1e6);
        if (a >= 1e3) return String.format("%s$%.1fK", sign, a / 1e3);
        return String.format("%s$%.0f", sign, a);
    }

    /** Plain number: 4000000 */
    public static String plain(double v) { return String.format("%.0f", v); }

    /** Short form that is EXACT: 4000000 -> "4m", 1500000 -> "1.5m", 250000 -> "250k". Falls back to the plain number when it can't be exact. */
    public static String abbr(double v) {
        if (v < 0) return "-" + abbr(-v);
        double[] units = {1e12, 1e9, 1e6, 1e3};
        String[] sfx = {"t", "b", "m", "k"};
        for (int i = 0; i < units.length; i++) {
            if (v >= units[i]) {
                double q = v / units[i];
                double r = Math.rint(q * 100) / 100;
                if (Math.abs(q - r) < 1e-9) {
                    return BigDecimal.valueOf(r).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString() + sfx[i];
                }
            }
        }
        return plain(v);
    }
}
