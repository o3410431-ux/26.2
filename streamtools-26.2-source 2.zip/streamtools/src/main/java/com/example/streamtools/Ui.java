package com.example.streamtools;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;

/** Drawing helpers for the nicer menus: panels, headers, little pixel icons and chips. */
public final class Ui {
    private Ui() {}

    // ---- text helpers (one place to change if the text-drawing method names change again) ----
    public static void text(GuiGraphicsExtractor g, Font f, String s, int x, int y, int color) { g.text(f, s, x, y, color, true); }
    public static void text(GuiGraphicsExtractor g, Font f, Component s, int x, int y, int color) { g.text(f, s, x, y, color, true); }
    public static void centered(GuiGraphicsExtractor g, Font f, String s, int cx, int y, int color) { g.text(f, s, cx - f.width(s) / 2, y, color, true); }
    public static void centered(GuiGraphicsExtractor g, Font f, Component s, int cx, int y, int color) { g.text(f, s, cx - f.width(s) / 2, y, color, true); }

    // ---- colours ----
    // Changeable from Settings > Colours. Plain RGB (no alpha). Use a(...) when an ARGB int is needed.
    public static int BLUE = 0x3AA0FF, GOLD = 0xFFD34D, GREEN = 0x55FF88, RED = 0xFF5555,
        ORANGE = 0xFFB347, CYAN = 0x55FFFF, GREY = 0x9AA0AB,
        HEADER_A = 0x2F7DD1, HEADER_B = 0x4B3A9B, BG = 0x161D2C, INFO = 0x8FD3FF;

    /** Setting names, labels and defaults for the Colours screen. Order matters: index = get/set index. */
    public static final String[] KEYS = {"BLUE", "GOLD", "GREEN", "RED", "ORANGE", "CYAN", "GREY", "HEADER_A", "HEADER_B", "BG", "INFO"};
    public static final String[] LABELS = {"Main accent / border", "Titles / gold", "Good / ON / profit", "Bad / OFF / loss",
        "Auction button", "Arrow button", "Settings button", "Header colour 1", "Header colour 2", "Panel background", "Info text / worth"};
    public static final int[] DEFAULTS = {0x3AA0FF, 0xFFD34D, 0x55FF88, 0xFF5555, 0xFFB347, 0x55FFFF, 0x9AA0AB, 0x2F7DD1, 0x4B3A9B, 0x161D2C, 0x8FD3FF};

    public static int get(int i) {
        return switch (i) {
            case 0 -> BLUE; case 1 -> GOLD; case 2 -> GREEN; case 3 -> RED; case 4 -> ORANGE;
            case 5 -> CYAN; case 6 -> GREY; case 7 -> HEADER_A; case 8 -> HEADER_B; case 9 -> BG; default -> INFO;
        };
    }

    public static void set(int i, int rgb) {
        rgb &= 0xFFFFFF;
        switch (i) {
            case 0 -> BLUE = rgb; case 1 -> GOLD = rgb; case 2 -> GREEN = rgb; case 3 -> RED = rgb;
            case 4 -> ORANGE = rgb; case 5 -> CYAN = rgb; case 6 -> GREY = rgb; case 7 -> HEADER_A = rgb; case 8 -> HEADER_B = rgb;
            case 9 -> BG = rgb; default -> INFO = rgb;
        }
    }

    public static void resetColors() { for (int i = 0; i < DEFAULTS.length; i++) set(i, DEFAULTS[i]); }

    /** RGB to fully opaque ARGB. */
    public static int a(int rgb) { return 0xFF000000 | rgb; }

    /** A dark panel with a coloured border, a soft shadow and a faint top highlight. */
    public static void panel(GuiGraphicsExtractor c, int x1, int y1, int x2, int y2, int accent) {
        c.fill(x1 + 3, y1 + 3, x2 + 3, y2 + 3, 0x66000000);
        c.fill(x1, y1, x2, y2, 0xFF000000 | accent);
        c.fillGradient(x1 + 1, y1 + 1, x2 - 1, y2 - 1, 0xF2000000 | BG, 0xF2000000 | (mix(a(BG), 0xFF000000, 0.45f) & 0xFFFFFF));
        c.fill(x1 + 1, y1 + 1, x2 - 1, y1 + 2, 0x33FFFFFF);
    }

    /** The coloured band across the top of a panel. */
    public static void header(GuiGraphicsExtractor c, int x1, int y1, int x2, int y2) {
        c.fillGradient(x1 + 1, y1 + 1, x2 - 1, y2, a(HEADER_A), a(HEADER_B));
        c.fill(x1 + 1, y2, x2 - 1, y2 + 1, lighten(a(HEADER_A), 0.6f));
    }

    /** A small rounded-looking label. Returns its width so chips can sit side by side. */
    public static int chip(GuiGraphicsExtractor c, Font tr, int x, int y, String text, int color) {
        int w = tr.width(text) + 10;
        c.fill(x, y, x + w, y + 12, 0xFF000000 | color);
        c.fill(x + 1, y + 1, x + w - 1, y + 11, mix(a(BG), 0xFF000000, 0.6f));
        c.fill(x + 1, y + 1, x + 4, y + 11, 0xFF000000 | color);
        Ui.text(c, tr, text, x + 7, y + 2, 0xFFEAF2FF);
        return w;
    }

    /** Blends colour a towards colour b (t = 0 is all a, 1 is all b). */
    public static int mix(int a, int b, float t) {
        int r = (int) ((a >> 16 & 255) * (1 - t) + (b >> 16 & 255) * t);
        int g = (int) ((a >> 8 & 255) * (1 - t) + (b >> 8 & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | r << 16 | g << 8 | bl;
    }

    public static int lighten(int argb, float amount) {
        int r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        r += (int) ((255 - r) * amount); g += (int) ((255 - g) * amount); b += (int) ((255 - b) * amount);
        return 0xFF000000 | r << 16 | g << 8 | b;
    }

    // ---- 8x8 pixel icons ----
    public static final String[] ELYTRA = {".ww..ww.", "wwmwwmww", "wmmmmmmw", "wmm..mmw", ".mm..mm.", ".m....m.", "........", "........"};
    public static final String[] ARROW = {"......tt", ".....ttt", "....bt..", "...b....", "..b.....", ".fb.....", "ff......", "f......."};
    public static final String[] COIN = {"..YYYY..", ".YyyyyY.", "Yyy..yyY", "Yyy..yyY", "Yyy..yyY", "Yyy..yyY", ".YyyyyY.", "..YYYY.."};
    public static final String[] CHART = {"........", ".......G", "......GG", "..G...GG", "..G.G.GG", ".GG.GGGG", ".GGGGGGG", "GGGGGGGG"};
    public static final String[] GEAR = {"...kk...", ".k.kk.k.", "..kkkk..", "kkk..kkk", "kkk..kkk", "..kkkk..", ".k.kk.k.", "...kk..."};
    public static final String[] CLOSE = {"r......r", ".r....r.", "..r..r..", "...rr...", "...rr...", "..r..r..", ".r....r.", "r......r"};

    private static int color(char ch) {
        return switch (ch) {
            case 'o' -> 0xFFC1693B; case 'd' -> 0xFF96502A; case 'w' -> 0xFFC3C7D3; case 'm' -> 0xFF7E8392;
            case 'b' -> 0xFF7A5632; case 't' -> 0xFF9AA0AB; case 'f' -> 0xFFF0F0F0; case 'Y' -> 0xFFE0A800;
            case 'y' -> 0xFFFFD34D; case 'G' -> 0xFF55FF88; case 'c' -> 0xFF55FFFF; 
            case 'k' -> 0xFFB4BCCB; case 'r' -> 0xFFFF5555; default -> 0;
        };
    }

    public static void sprite(GuiGraphicsExtractor c, int x, int y, String[] rows, int scale) {
        if (rows == null) return;
        for (int row = 0; row < rows.length; row++)
            for (int col = 0; col < rows[row].length(); col++) {
                int argb = color(rows[row].charAt(col));
                if (argb != 0) c.fill(x + col * scale, y + row * scale, x + (col + 1) * scale, y + (row + 1) * scale, argb);
            }
    }
}
