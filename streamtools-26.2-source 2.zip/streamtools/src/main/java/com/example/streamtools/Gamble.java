package com.example.streamtools;

import java.util.ArrayDeque;
import java.util.Deque;

/** Manual wager mode: no rolling, no payouts. You decide each result with the chat buttons. */
public final class Gamble {
    public static boolean enabled = false;
    public static final Deque<String> history = new ArrayDeque<>();

    public static void recordLoss(String player, double amt) {
        history.addFirst(player + " " + Money.fmt(amt) + " LOSS");
        while (history.size() > 5) history.removeLast();
    }
}
