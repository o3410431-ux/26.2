package com.example.streamtools;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Options changed from the Payments and Settings screens. Saved in config/streamtools-settings.txt. */
public final class Settings {
    public static double minPay = 1_000_000;   // smallest payment that gets [W] [R] [X]
    public static double winMult = 2;          // [W] pays the player this many times their payment
    public static boolean buttons = true;
    /** Width of the menu screens: 0.7 to 1.5 (Settings > Menu width). */
    public static double menuScale = 1.0;

    /** A menu's width: the normal width times the Menu width setting, never wider than the window. */
    public static int menuW(int base, int screenW) {
        int v = (int) Math.round(base * menuScale);
        return Math.max(160, Math.min(v, screenW - 12));
    }      // pay buttons on/off

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("streamtools-settings.txt");

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            for (String l : Files.readAllLines(FILE)) {
                int i = l.indexOf('=');
                if (i < 0) continue;
                String k = l.substring(0, i).trim(), v = l.substring(i + 1).trim();
                switch (k) {
                    case "minPay" -> minPay = Double.parseDouble(v);
                    case "winMult" -> winMult = Double.parseDouble(v);
                    case "buttons" -> buttons = Boolean.parseBoolean(v);
                    case "hud" -> Hud.visible = Boolean.parseBoolean(v);
                    case "hudX" -> Hud.x = Integer.parseInt(v);
                    case "hudY" -> Hud.y = Integer.parseInt(v);
                    case "live" -> Hud.liveVisible = Boolean.parseBoolean(v);
                    case "liveX" -> Hud.liveX = Integer.parseInt(v);
                    case "liveY" -> Hud.liveY = Integer.parseInt(v);
                    case "menuScale" -> menuScale = Math.max(0.7, Math.min(1.5, Double.parseDouble(v)));
                    case "hudScale" -> Hud.scale = Math.max(0.5, Math.min(3.0, Double.parseDouble(v)));
                    default -> {
                        if (k.startsWith("color.")) {
                            for (int c = 0; c < Ui.KEYS.length; c++)
                                if (k.equals("color." + Ui.KEYS[c])) Ui.set(c, Integer.parseInt(v.replace("#", ""), 16));
                        }
                    }
                }
            }
        } catch (Exception ignored) { }
    }

    public static void save() {
        try {
            StringBuilder colors = new StringBuilder();
            for (int c = 0; c < Ui.KEYS.length; c++)
                colors.append("color.").append(Ui.KEYS[c]).append('=').append(String.format("%06X", Ui.get(c))).append('\n');
            Files.writeString(FILE, colors + "minPay=" + minPay + "\nwinMult=" + winMult + "\nbuttons=" + buttons + "\nhud=" + Hud.visible + "\nhudX=" + Hud.x + "\nhudY=" + Hud.y + "\nhudScale=" + Hud.scale + "\nlive=" + Hud.liveVisible + "\nliveX=" + Hud.liveX + "\nliveY=" + Hud.liveY + "\nmenuScale=" + menuScale + "\n");
        } catch (Exception ignored) { }
    }

    public static String num(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v);
    }
}
