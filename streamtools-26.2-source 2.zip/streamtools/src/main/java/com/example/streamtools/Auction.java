package com.example.streamtools;

import net.minecraft.world.item.ItemStack;

public final class Auction {
    public static final String TITLE = "Bid Mod by Oll1eonMC";

    public static boolean active = false;
    /** After an auction ends the HUD box stays up showing the result for SHOW_END_MS. */
    public static boolean ended = false;
    public static long endedAt = 0;
    public static final long SHOW_END_MS = 20_000;

    public static String item = "";
    public static ItemStack stack = ItemStack.EMPTY;
    public static double minBid = 0;
    /** What the item is worth, typed in when you set the auction up. NaN = not set. */
    public static double worth = Double.NaN;
    public static double topBid = 0;
    public static String topBidder = "-";
    public static int bids = 0;
    public static long endAt = 0;
    /** Extra seconds added after the timer runs out (the "snipe" box). 0 = none. */
    public static long antiSnipeMs = 0;
    /** True once the extra time has started. */
    public static boolean overtime = false;
    /** Today's profit when the auction started: the Live pill shows this while bidding runs. */
    public static double liveFrozen = 0;

    /** Every payment received while the auction ran, added up (all the bids). */
    public static double totalBids = 0;

    public static void start(ItemStack stack, String name, double minBid, int seconds, double worth) {
        Auction.stack = stack; item = name; Auction.minBid = minBid; Auction.worth = worth;
        topBid = 0; topBidder = "-"; bids = 0;
        totalBids = 0;
        liveFrozen = Tracker.todayProfit();
        ended = false;
        overtime = false;
        endAt = System.currentTimeMillis() + seconds * 1000L; active = true;
    }

    /** A payment to the streamer is a bid if it meets the minimum and beats the top bid. */
    public static boolean bid(String name, double amt) {
        if (!active || amt < minBid || amt <= topBid) return false;
        topBid = amt; topBidder = name; bids++;
        return true;
    }

    /** Profit from this auction: all the bids added up, minus the worth you typed in. NaN if nobody won or no worth was set. */
    public static double profit() {
        if (topBidder.equals("-") || Double.isNaN(worth)) return Double.NaN;
        return totalBids - worth;
    }

    public static String profitText() {
        double p = profit();
        if (Double.isNaN(p)) return "none";
        return (p > 0 ? "+" : "") + Money.fmt(p);
    }

    public static long msLeft() { return Math.max(0, endAt - System.currentTimeMillis()); }
    public static boolean showEnd() { return ended && System.currentTimeMillis() - endedAt < SHOW_END_MS; }
    /** Ends the auction right now, with no extra time (the Stop button). */
    public static void stopNow() { overtime = true; endAt = 0; }

    /** Called every tick. When the timer runs out, the snipe seconds (if any) are added once; the next time it runs out the auction is over. */
    public static boolean expired() {
        if (!active || msLeft() > 0) return false;
        if (antiSnipeMs > 0 && !overtime) {
            overtime = true;
            endAt = System.currentTimeMillis() + antiSnipeMs;
            return false;
        }
        return true;
    }
}
