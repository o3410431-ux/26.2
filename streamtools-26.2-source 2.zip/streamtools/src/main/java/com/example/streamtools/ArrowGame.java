package com.example.streamtools;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Streamer-defined price list for the arrow game. A payment that exactly matches a price gets [Deliver] / [Lose] buttons. */
public final class ArrowGame {
    /** cmd is the delivery command template; {name} = the payer, {amount} = what they paid, {label} = tier name. */
    public record Tier(String name, double price, String cmd) {}

    public static final int MAX = 6;
    public static final String DEFAULT_CMD = "/orders {name}";
    public static boolean enabled = true;
    /** Work out WON / LOST from where your arrows go (a hit on a map = won). */
    public static boolean autoResults = true;
    public static final List<Tier> tiers = new ArrayList<>();

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("streamtools-arrow.txt");

    public static Tier find(double amount) {
        for (Tier t : tiers) if (Math.abs(t.price() - amount) < 0.5) return t;
        return null;
    }

    /** The delivery command for this payment, ready to paste into chat (never sent automatically). */
    public static String command(Tier t, String player, double amount) {
        String c = (t.cmd() == null || t.cmd().isBlank() ? DEFAULT_CMD : t.cmd().trim())
            .replace("{name}", player).replace("{amount}", Money.abbr(amount)).replace("{label}", t.name());
        return c.startsWith("/") ? c : "/" + c;
    }

    /** Adds a price, or replaces the tier if that exact price already exists. Returns false when the list is full. */
    public static boolean add(String name, double price, String cmd) {
        name = name.replace("|", "/").trim();
        cmd = (cmd == null || cmd.isBlank() ? DEFAULT_CMD : cmd.replace("|", "").trim());
        boolean exists = find(price) != null;
        if (!exists && tiers.size() >= MAX) return false;
        tiers.removeIf(t -> Math.abs(t.price() - price) < 0.5);
        tiers.add(new Tier(name, price, cmd));
        tiers.sort(Comparator.comparingDouble(Tier::price));
        save();
        return true;
    }

    public static void remove(int index) {
        if (index >= 0 && index < tiers.size()) { tiers.remove(index); save(); }
    }

    public static void setEnabled(boolean on) { enabled = on; save(); }
    public static void setAuto(boolean on) { autoResults = on; save(); }

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            tiers.clear();
            for (String line : Files.readAllLines(FILE)) {
                if (line.startsWith("enabled=")) { enabled = Boolean.parseBoolean(line.substring(8).trim()); continue; }
                if (line.startsWith("auto=")) { autoResults = Boolean.parseBoolean(line.substring(5).trim()); continue; }
                if (line.startsWith("range=")) continue;   // an old setting that no longer exists
                String[] p = line.split("\\|", 3);          // price|name|cmd
                if (p.length < 2) continue;
                tiers.add(new Tier(p[1].trim(), Double.parseDouble(p[0].trim()), p.length > 2 ? p[2].trim() : DEFAULT_CMD));
            }
            tiers.sort(Comparator.comparingDouble(Tier::price));
        } catch (Exception ignored) { }
    }

    private static void save() {
        try {
            StringBuilder sb = new StringBuilder("enabled=" + enabled + "\nauto=" + autoResults + "\n");
            for (Tier t : tiers) sb.append(Money.plain(t.price())).append('|').append(t.name()).append('|').append(t.cmd()).append('\n');
            Files.writeString(FILE, sb.toString());
        } catch (Exception ignored) { }
    }
}
