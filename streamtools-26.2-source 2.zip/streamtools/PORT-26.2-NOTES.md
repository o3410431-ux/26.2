# 26.2 port notes (hand-ported from the 1.21.11 Yarn source, NOT compiled)

Minecraft 26.x is unobfuscated, so every Minecraft name was changed from Yarn to Mojang names by hand.
If the build fails, the errors will almost certainly be in this short list of guesses:

- Ui.java: text-drawing helpers use GuiGraphicsExtractor.text(font, text, x, y, color, shadow)
  (shown in the Fabric 26.2 docs). Items are drawn with graphics.item(stack, x, y) (a guess).
- StyledButton.java and AuctionScreen.ItemRow: they override Button.extractContents(...) to repaint the button
  (the old drawIcon hook). If that name is wrong, find the method that draws a Button's label in 26.2.
- Hud.java: HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, ...) (from the Fabric docs; check the imports).
- StreamTools.java: KeyMappingHelper package (net.fabricmc.fabric.api.client.keymapping.v1), KeyMapping.Category.register,
  Minecraft.gui.setScreen / gui.screen() (from the docs).
- ChatEdit.java + mixin/ChatHudAccessor.java: GuiMessage fields (addedTime, content, signature, tag), ChatComponent field
  "allMessages" and method "refreshTrimmedMessages". If these are wrong the [W]/[R]/[X] lines still appear but won't change to WON/LOST.
- ArrowWatch.java: Level/AABB/ClipContext names. Arrows are matched by EntityType (ARROW, SPECTRAL_ARROW, TRIDENT).
- HudPositionScreen.java: Window.handle() for reading the mouse button.
- build.gradle: Loom plugin net.fabricmc.fabric-loom 1.17-SNAPSHOT, Java 25. Check https://fabricmc.net/develop.
