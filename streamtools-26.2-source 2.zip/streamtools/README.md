# Bid Mod by Oll1eonMC (Fabric, client-side)

Build: see BUILD.md. Put the jar and Fabric API in .minecraft/mods.

## Commands
/st opens the panel (Right Shift does too). Press 0 to jump straight to Auction setup. Both keys can be changed in Minecraft's Controls screen. Everything else is on the panel screens.
/profit prints today's Profit, Received and Sent out in chat.
(The [X] and [Lose] buttons run "/st <number>" behind the scenes. You never type that.)

## HUD
Two things can show on screen. The auction box (while an auction runs and for 20 seconds after) and the small "Live | +$348.7M" pill, which is today's profit (money in minus money out). Settings > Live profit turns the pill on/off. While an auction runs the pill stays at its value from when the auction started, so bids aren't revealed; it catches up when the auction ends.
Settings > Move HUD: drag either box with your mouse (press on the box you want, no need to pick it first), Smaller / Bigger resize both, Reset puts both back and the size to 100%.

## /profit
Profit: money in minus money out today.
Received: payments people sent you + things you sold.
Sent out: payments you sent + things you bought ("You bought .. for $.." / "You sold .. for $.." chat lines).
Resets at midnight; Settings > Reset today clears it.

## Auction
Search any item, click it, set the minimum bid, an optional Worth, the duration and an optional Snipe, then press Start bid.
Payments to you are bids (a bid must meet the minimum and beat the top bid). Snipe is optional: leave it empty for none, or type seconds and when the timer runs out that many extra seconds are added (the time shows "(extra)"), then the auction ends. Stop ends it straight away. While it runs, payment lines get no pay buttons.
Every payment received during the auction is added up as "Bids total". If you typed a Worth, the ended box and chat show Bids total, Worth and Auction profit = bids total minus worth. With no Worth, no profit is shown anywhere.

## Payments and arrow game lines
"X paid you $Y" of the minimum (default 1m) or more gets [W] [R] [X]; an exact arrow game price gets [Deliver] [Lose]. "Current >" marks the oldest unfinished line; buttons turn into LOST / WON / REPAID / DELIVERED on the same line. Nothing is ever sent for you.

## Numbers
Every amount box takes short forms: 500k, 1m, 1.5m, 2b, 1t, or all the digits. Pasted /pay commands are short too (/pay Name 4m) whenever that is exact.

## Panel > Profit
Type your exact starting balance; the screen shows how far up or down you are (tracked from the same chat lines). Sync fixes any drift.

## Results stay on the payment's own row
Results (WON, LOST, REPAID, DELIVERED) replace the buttons on the same chat line and are kept short so the line fits. If a line still wraps onto a second row, widen the chat: Options > Chat Settings > Width. A payment line that has scrolled out of the chat history is forgotten, so "Current >" moves on to the next line still on screen.
Keys: Right Shift opens the panel, 0 jumps straight to Auction setup (both can be changed in Controls).

## When the buttons go away
[X] flips the line to LOST right away. For [W] and [R], paste the /pay and press Enter: the moment the /pay command is sent the line flips to WON (the win amount) or REPAID (the same amount), and the [W] [R] [X] buttons disappear. The server's "You paid .." message also does this, as a backup. For arrow lines, [Lose] flips to LOST and sending the delivery command flips to DELIVERED.

## Reset Current
Payment buttons > Reset Current: clears the waiting payment lines out of the "Current >" queue. The "Current >" comes off, and the next payment that arrives gets it. Old lines still work if you click their buttons.

## Worth on the box
If you typed a Worth it shows on the auction box the whole time ("Worth: $340.00M") and again at the end next to the auction profit.

## /bal sets Profit up for you
Run /bal (or /balance, /money). The mod reads the amount from the reply (the next message in the next 6 seconds with a $ amount), and: if you hadn't set a starting balance it uses that as the starting balance; otherwise it sets your current balance to it. It tells you in chat, and Panel > Profit shows the up or down figure. Checking someone else (/bal Steve) never touches your profit: it is ignored, and for 10 seconds any reply that names that player is ignored too.

## Menu size
Settings > Menu width (- / +) makes the menu screens narrower or wider (70% to 150%), for example how wide Auction setup is. It updates straight away and is remembered.
The screens also fit short windows: the Auction setup list shows fewer rows and the Arrow game rows get shorter when the window is short, and Back / Start bid always sit at the bottom edge of the window, so you never have to go fullscreen to reach them.

## Menu width and short windows
Settings > Menu width (- / +): makes every menu screen narrower or wider (70% to 150%). It never gets wider than the window.
In a small window the menus keep their bottom buttons (Back) on screen: the auction list shows fewer rows and the arrow game rows get shorter, so you don't have to go fullscreen to click Back.

Arrow game screen: Back and the Arrow ON/OFF button are in a row at the very top of the screen, so Back is never low down. The price list uses the room underneath.

## Reset profit
Panel > Profit > Reset profit: starts the profit again from where you are now. The up/down figure goes back to zero (your starting balance becomes your current balance), and today's profit, the Live pill and /profit go back to zero too.

Works for servers that send chat as normal player messages (the sender is known exactly) and for servers that send it as plain text lines. DonutSMP-style lines ("Name: message", with a dot in front of Bedrock names) are recognised out of the box. If your server looks different, press "Learn chat format", close the menu, and send any message in public chat. The mod looks at how your own message comes back, learns what sits between the name and the message (for example " » "), and tells you in chat when it has it. It is saved, so you only do it once.

## Result lines are found by their button
Each payment line is found in the chat by the hidden id on its [X] / [Lose] button, not by its text, so [X] and a finished /pay always change the right line even when several payments look the same or another mod re-wraps the message. The history of payment lines is 500 deep, and when two lines are for the same player the oldest one (the one marked "Current >") is finished first.

## Arrow game: automatic results
While the arrow game is ON (and Settings > Arrow auto result is ON), the mod follows every arrow you shoot. An arrow that reaches an item frame holding a MAP is a win: the oldest unfinished arrow game line becomes  WON ✔ [Pay 4m]  ([Pay] pastes the winnings, you press Enter). An arrow that hits anything else, or nothing, is a loss: that line becomes  LOST ✖. It only counts when an arrow game line is waiting, so shooting arrows with nothing waiting does nothing. One arrow = one line, oldest first.

## New look
The main panel and the auction setup are redrawn with dark panels, a coloured header, flat buttons with little icons that light up on hover, status chips on the main panel, and striped item rows with an accent bar on the one you picked. (Ui.java and StyledButton.java.)
