package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** A flat button with a coloured edge, a gradient that lights up on hover, and an optional little icon. */
public class StyledButton extends Button {
    private final int accent;
    private final String label;
    private final String[] icon;

    // OnPress is Button's own press-callback type
    public StyledButton(int x, int y, int w, int h, String label, int accent, String[] icon, OnPress onPress) {
        super(x, y, w, h, Component.literal(label), onPress, DEFAULT_NARRATION);
        this.accent = accent;
        this.label = label;
        this.icon = icon;
    }

    // renderWidget is final in this version, so the whole look is drawn over the default button in renderContents
    @Override
    protected void renderContents(GuiGraphics c, int mx, int my, float d) {
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        boolean hover = isHovered() && this.active;
        int edge = 0xFF000000 | accent;
        int top = Ui.lighten(Ui.a(Ui.BG), 0.08f), bottom = Ui.mix(Ui.a(Ui.BG), 0xFF000000, 0.2f);
        c.fill(x, y, x + w, y + h, edge);
        c.fillGradient(x + 1, y + 1, x + w - 1, y + h - 1,
            hover ? Ui.mix(top, edge, 0.45f) : top,
            hover ? Ui.mix(bottom, edge, 0.25f) : bottom);
        c.fill(x + 1, y + 1, x + 4, y + h - 1, edge);                       // coloured bar on the left

        Font tr = Minecraft.getInstance().font;
        int left = x + 8;
        if (icon != null) { Ui.sprite(c, x + 8, y + (h - 8) / 2, icon, 1); left = x + 20; }
        int room = x + w - 4 - left;
        int tw = tr.width(label);
        int tx = left + Math.max(0, (room - tw) / 2);
        Ui.text(c, tr, label, tx, y + (h - 8) / 2, hover ? 0xFFFFFFFF : 0xFFDDE6F5);
    }
}
