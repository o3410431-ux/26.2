package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** HUD on/off, Live profit on/off, move the HUD, menu width, and resets. */
public class SettingsScreen extends Screen {
    private int W = 240;
    private Component status = Component.empty();
    private int x0, y0;

    public SettingsScreen() { super(Component.literal("Settings")); }

    @Override
    protected void init() {
        W = Math.max(200, Settings.menuW(240, width));
        x0 = (width - W) / 2;
        y0 = Math.max(2, Math.min(Math.max(6, (height - 262) / 2), height - 238));

        addRenderableWidget(Button.builder(hudText(), b -> {
            Hud.visible = !Hud.visible;
            Settings.save();
            b.setMessage(hudText());
        }).bounds(x0, y0 + 22, W, 20).build());

        addRenderableWidget(Button.builder(liveText(), b -> {
            Hud.liveVisible = !Hud.liveVisible;
            Settings.save();
            b.setMessage(liveText());
        }).bounds(x0, y0 + 48, W, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Move HUD"), b -> minecraft.setScreen(new HudPositionScreen()))
            .bounds(x0, y0 + 74, W, 20).build());

        addRenderableWidget(Button.builder(autoText(), b -> {
            ArrowGame.setAuto(!ArrowGame.autoResults);
            b.setMessage(autoText());
        }).bounds(x0, y0 + 100, W, 20).build());

        // Menu width: - [Menu width: 100%] +
        addRenderableWidget(Button.builder(Component.literal("-"), b -> resizeMenu(-0.1))
            .bounds(x0, y0 + 126, 30, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> resizeMenu(0.1))
            .bounds(x0 + W - 30, y0 + 126, 30, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Colours..."), b -> minecraft.setScreen(new ColorScreen()))
            .bounds(x0, y0 + 152, W, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Reset session"), b -> {
            Tracker.reset();
            status = Component.literal("Session totals reset").withColor(0xAAAAAA);
        }).bounds(x0, y0 + 182, W / 2 - 2, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset today"), b -> {
            Tracker.resetToday();
            status = Component.literal("Today's profit reset").withColor(0xAAAAAA);
        }).bounds(x0 + W / 2 + 2, y0 + 182, W / 2 - 2, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Back"), b -> MainScreen.open())
            .bounds(x0, y0 + 210, W, 20).build());
    }

    private void resizeMenu(double d) {
        Settings.menuScale = Math.max(0.7, Math.min(1.5, Math.round((Settings.menuScale + d) * 10) / 10.0));
        Settings.save();
        rebuildWidgets();   // redraw this screen at the new width right away
    }

    private Component hudText() { return Component.literal("HUD: " + (Hud.visible ? "ON" : "OFF")); }
    private Component autoText() { return Component.literal("Arrow auto result: " + (ArrowGame.autoResults ? "ON" : "OFF")); }
    private Component liveText() { return Component.literal("Live profit: " + (Hud.liveVisible ? "ON" : "OFF")); }

    @Override
    public void render(GuiGraphics ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        Ui.centered(ctx, font, title, width / 2, y0 + 6, Ui.a(Ui.GOLD));
        Ui.centered(ctx, font, "Menu width: " + Math.round(Settings.menuScale * 100) + "%", width / 2, y0 + 132, 0xFFFFFFFF);
        Ui.centered(ctx, font, status, width / 2, y0 + 236, 0xFFFFFFFF);
    }

    @Override public boolean isPauseScreen() { return false; }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.setScreen(new SettingsScreen()));
    }
}
