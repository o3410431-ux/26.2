package com.example.streamtools;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Drag either box (the auction box or the Live pill) with the mouse. Smaller / Bigger resize both. */
public class HudPositionScreen extends Screen {
    private boolean dragging = false, dragLive = false, wasDown = false;
    private int grabX, grabY;

    public HudPositionScreen() { super(Component.literal("Move HUD")); }

    @Override
    protected void init() {
        int cx = width / 2, by = height - 30;
        addRenderableWidget(Button.builder(Component.literal("Smaller"), b -> resize(-0.1))
            .bounds(cx - 130, by, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Bigger"), b -> resize(0.1))
            .bounds(cx - 64, by, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset"), b -> reset())
            .bounds(cx + 2, by, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> { Settings.save(); SettingsScreen.open(); })
            .bounds(cx + 68, by, 62, 20).build());
    }

    // ---- the two boxes (positions are already clamped on screen) ----
    private int aw() { return Hud.w(); }
    private int ah() { return Hud.h(); }
    private int ax() { return Math.max(0, Math.min(Hud.x, width - aw())); }
    private int ay() { return Math.max(0, Math.min(Hud.y, height - ah())); }

    private int lw() { return Hud.liveScaledW(font); }
    private int lh() { return Hud.liveScaledH(); }
    private int lx() { return Hud.resolveLiveX(width, lw()); }
    private int ly() { return Hud.resolveLiveY(height, lh()); }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void placeAuction(int x, int y) {
        Hud.x = Math.max(0, Math.min(x, width - aw()));
        Hud.y = Math.max(0, Math.min(y, height - ah()));
    }

    private void placeLive(int x, int y) {
        Hud.liveX = Math.max(0, Math.min(x, width - lw()));
        Hud.liveY = Math.max(0, Math.min(y, height - lh()));
    }

    private void resize(double d) {
        Hud.scale = Math.max(0.5, Math.min(3.0, Math.round((Hud.scale + d) * 10) / 10.0));
        placeAuction(ax(), ay());          // keep both on screen after growing
        if (Hud.liveX >= 0) placeLive(lx(), ly());
    }

    private void reset() {
        Hud.scale = 1.0;
        Hud.x = 6; Hud.y = 6;
        Hud.liveX = -1; Hud.liveY = -1;
    }

    private void ghost(GuiGraphics ctx, int x1, int y1, int w, int h, String label, int state) {
        // state: 0 = idle, 1 = mouse is over it, 2 = being dragged
        int x2 = x1 + w, y2 = y1 + h;
        int line = state == 2 ? Ui.a(Ui.GOLD) : (state == 1 ? 0xFF6CB4EE : 0x886CB4EE);
        ctx.fill(x1, y1, x2, y2, state == 0 ? 0x333A7CC0 : 0x663A7CC0);
        ctx.fill(x1, y1, x2, y1 + 1, line);
        ctx.fill(x1, y2 - 1, x2, y2, line);
        ctx.fill(x1, y1, x1 + 1, y2, line);
        ctx.fill(x2 - 1, y1, x2, y2, line);
        if (h >= 14) Ui.text(ctx, font, label, x1 + 4, y1 + Math.max(2, (h - 8) / 2), state == 0 ? 0xFFAAAAAA : 0xFFFFFFFF);
    }

    @Override
    public void render(GuiGraphics ctx, int mouseX, int mouseY, float delta) {
        // Mouse dragging: the left button is read directly each frame. Whichever box you press on is the one that moves.
        long window = Minecraft.getInstance().getWindow().handle();
        boolean down = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean onButtons = mouseY >= height - 34;
        boolean overLive = !onButtons && inside(mouseX, mouseY, lx(), ly(), lw(), lh());
        boolean overAuction = !onButtons && !overLive && inside(mouseX, mouseY, ax(), ay(), aw(), ah());

        if (down && !wasDown) {
            if (overLive) { dragging = true; dragLive = true; grabX = mouseX - lx(); grabY = mouseY - ly(); }
            else if (overAuction) { dragging = true; dragLive = false; grabX = mouseX - ax(); grabY = mouseY - ay(); }
        }
        if (!down) dragging = false;
        if (dragging) {
            if (dragLive) placeLive(mouseX - grabX, mouseY - grabY);
            else placeAuction(mouseX - grabX, mouseY - grabY);
        }
        wasDown = down;

        super.render(ctx, mouseX, mouseY, delta);

        int aState = dragging && !dragLive ? 2 : (overAuction ? 1 : 0);
        int lState = dragging && dragLive ? 2 : (overLive ? 1 : 0);
        ghost(ctx, ax(), ay(), aw(), ah(), "Auction box", aState);
        ghost(ctx, lx(), ly(), lw(), lh(), "Live", lState);

        Ui.centered(ctx, font, title, width / 2, 8, Ui.a(Ui.GOLD));
        Ui.centered(ctx, font, "Drag either box with your mouse. Smaller / Bigger resize both, then press Done", width / 2, 22, 0xFFAAAAAA);
        Ui.centered(ctx, font, "Size " + Math.round(Hud.scale * 100) + "%", width / 2, height - 44, 0xFFFFFFFF);
    }

    @Override public void removed() { Settings.save(); }
    @Override public boolean isPauseScreen() { return false; }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.setScreen(new HudPositionScreen()));
    }
}
