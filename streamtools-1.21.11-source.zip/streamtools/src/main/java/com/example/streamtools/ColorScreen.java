package com.example.streamtools;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

/**
 * Settings > Colours. Every colour has a swatch, a hex box (type e.g. FF8800 or #FF8800) and a button that
 * steps through a few ready-made colours. Changes apply instantly and are saved. Scroll the list with the
 * mouse wheel or the Up / Down buttons if the window is short.
 */
public class ColorScreen extends Screen {
    private static final int[] PRESETS = {
        0x3AA0FF, 0xFFD34D, 0x55FF88, 0xFF5555, 0xB06CFF, 0xFFB347, 0x55FFFF, 0xFF66C4, 0xFFFFFF, 0x9AA0AB,
        0x2F7DD1, 0x4B3A9B, 0x1B8A5A, 0xB0302A, 0x161D2C, 0x0B0F19, 0x2A1B3D, 0x3D2A1B, 0x1B3D2A, 0x000000
    };
    private static final int ROW = 24;

    private int W = 280, x0, y0, rows, scroll;
    private final EditBox[] fields = new EditBox[Ui.KEYS.length];
    private final String[] typed = new String[Ui.KEYS.length];
    private Component status = Component.empty();

    public ColorScreen() { super(Component.literal("Colours")); }

    @Override
    protected void init() {
        W = Math.max(250, Settings.menuW(280, width));
        x0 = (width - W) / 2;
        rows = Math.max(3, Math.min(Ui.KEYS.length, (height - 80) / ROW));
        scroll = Math.max(0, Math.min(scroll, Ui.KEYS.length - rows));
        int total = 22 + rows * ROW + 30;
        y0 = Math.max(2, (height - total) / 2);

        for (int r = 0; r < rows; r++) {
            final int idx = scroll + r;
            int y = y0 + 22 + r * ROW;
            // swatch is drawn in render at x0 + 0..20
            EditBox f = new EditBox(font, x0 + W - 170, y, 66, 18, Component.literal(Ui.LABELS[idx]));
            f.setMaxLength(7);
            f.setValue(typed[idx] != null ? typed[idx] : String.format("%06X", Ui.get(idx)));
            f.setResponder(t -> {
                typed[idx] = t;
                try {
                    String h = t.trim().replace("#", "");
                    if (h.length() == 6) {
                        Ui.set(idx, Integer.parseInt(h, 16));
                        Settings.save();
                    }
                } catch (NumberFormatException ignored) { }
            });
            fields[idx] = f;
            addRenderableWidget(f);

            addRenderableWidget(Button.builder(Component.literal("<"), b -> step(idx, -1)).bounds(x0 + W - 100, y, 22, 18).build());
            addRenderableWidget(Button.builder(Component.literal(">"), b -> step(idx, 1)).bounds(x0 + W - 76, y, 22, 18).build());
            addRenderableWidget(Button.builder(Component.literal("Def"), b -> {
                Ui.set(idx, Ui.DEFAULTS[idx]);
                typed[idx] = null;
                Settings.save();
                rebuildWidgets();
            }).bounds(x0 + W - 52, y, 52, 18).build());
        }

        int by = y0 + 22 + rows * ROW + 4;
        if (rows < Ui.KEYS.length) {
            addRenderableWidget(Button.builder(Component.literal("Up"), b -> scrollBy(-1)).bounds(x0, by, 40, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Down"), b -> scrollBy(1)).bounds(x0 + 44, by, 40, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Reset all"), b -> {
            Ui.resetColors();
            java.util.Arrays.fill(typed, null);
            Settings.save();
            status = Component.literal("Colours reset").withColor(Ui.GREEN);
            rebuildWidgets();
        }).bounds(x0 + W / 2 - 40, by, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> minecraft.setScreen(new SettingsScreen()))
            .bounds(x0 + W - 60, by, 60, 20).build());
    }

    private void step(int idx, int dir) {
        int cur = Ui.get(idx), at = -1;
        for (int i = 0; i < PRESETS.length; i++) if (PRESETS[i] == cur) at = i;
        int next = PRESETS[Math.floorMod(at + dir, PRESETS.length)];
        Ui.set(idx, next);
        typed[idx] = null;
        Settings.save();
        if (fields[idx] != null) fields[idx].setValue(String.format("%06X", next));
        typed[idx] = null;
    }

    private void scrollBy(int d) {
        scroll = Math.max(0, Math.min(Ui.KEYS.length - rows, scroll + d));
        rebuildWidgets();
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (rows < Ui.KEYS.length && v != 0) { scrollBy(v > 0 ? -1 : 1); return true; }
        return super.mouseScrolled(mx, my, h, v);
    }

    @Override
    public void render(GuiGraphics ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        Ui.centered(ctx, font, title, width / 2, y0 + 4, Ui.a(Ui.GOLD));
        for (int r = 0; r < rows; r++) {
            int idx = scroll + r, y = y0 + 22 + r * ROW;
            ctx.fill(x0, y, x0 + 20, y + 18, 0xFFFFFFFF);
            ctx.fill(x0 + 1, y + 1, x0 + 19, y + 17, Ui.a(Ui.get(idx)));
            Ui.text(ctx, font, font.plainSubstrByWidth(Ui.LABELS[idx], W - 200), x0 + 26, y + 5, 0xFFFFFFFF);
        }
        Ui.centered(ctx, font, status, width / 2, y0 + 14, 0xFFFFFFFF);
    }

    @Override public boolean isPauseScreen() { return false; }
}
