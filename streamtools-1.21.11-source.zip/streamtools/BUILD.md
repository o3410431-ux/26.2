# Easiest way to get the .jar

## Option A: Fabric template (about 5 minutes, needs JDK 21)
1. Go to https://fabricmc.net/develop/template
2. Pick Minecraft 1.21.11, choose "Mojang" mappings (this source uses Mojang names, not Yarn), and UNTICK "split client and common sources". Download and unzip it.
3. Delete the template's `src` folder and copy this project's `src` folder in its place.
4. Open a terminal in the template folder and run:  gradlew build   (Mac/Linux: ./gradlew build)
5. Your mod is build/libs/<name>.jar (not the one ending in -sources).
   You can ignore this project's own build.gradle, gradle.properties and settings.gradle.

## Option B: build in the cloud, no Java needed
1. Do steps 1-3 above, then also copy this project's `.github` folder into the template folder.
2. Create a free GitHub account and a new repository, then upload the template folder's contents.
3. Open the repository's Actions tab, wait for "build" to go green, open the run, and download the "streamtools-jar" artifact. Unzip it to get the jar.

Then put the jar and Fabric API in your .minecraft/mods folder.
